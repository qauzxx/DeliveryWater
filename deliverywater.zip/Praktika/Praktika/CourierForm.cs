﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace Praktika
{
    public class CourierForm : Form
    {
        private readonly string _connectionString;
        private readonly DataGridView _dgvOrders;
        private readonly Button _btnRefresh;
        private readonly Button _btnToDelivery;
        private readonly Button _btnDelivered;
        private readonly Button _btnBack;

        public CourierForm()
        {
            InitializeComponent();
            _connectionString = DatabaseHelper.GetConnectionString();

            Text = "Курьер - Доставка воды";
            StartPosition = FormStartPosition.CenterScreen;
            MinimumSize = new Size(760, 420);
            Size = new Size(900, 520);
            BackgroundImageLayout = ImageLayout.Stretch;
            Padding = new Padding(30, 30, 30, 30);

            _dgvOrders = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                MultiSelect = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };

            var panel = new Panel { Dock = DockStyle.Bottom, Height = 44 };
            _btnRefresh = new Button { Text = "Обновить", Width = 100, Left = 8, Top = 8 };
            _btnToDelivery = new Button { Text = "В доставке", Width = 120, Left = 116, Top = 8 };
            _btnDelivered = new Button { Text = "Доставлен", Width = 120, Left = 244, Top = 8 };
            _btnBack = new Button { Text = "Назад", Width = 100, Left = 372, Top = 8 };

            panel.BackColor = Color.FromArgb(230, 255, 255, 255);
            panel.Controls.AddRange(new Control[] { _btnRefresh, _btnToDelivery, _btnDelivered, _btnBack });
            Controls.Add(_dgvOrders);
            Controls.Add(panel);

            _btnRefresh.Click += (s, e) => LoadOrders();
            _btnToDelivery.Click += (s, e) => UpdateOrderStatus("В доставке");
            _btnDelivered.Click += (s, e) => UpdateOrderStatus("Доставлен");
            _btnBack.Click += (s, e) => Close();

            Load += (s, e) => LoadOrders();
        }

        private void LoadOrders()
        {
            try
            {
                using (var conn = new SqlConnection(_connectionString))
                using (var da = new SqlDataAdapter(
                           @"SELECT o.Id, c.FullName AS [Клиент], c.Phone AS [Телефон], o.DeliveryAddress AS [Адрес],
o.OrderDate AS [Дата], o.TotalAmount AS [Сумма], s.Name AS [Статус]
FROM Orders o
INNER JOIN Customers c ON c.Id = o.CustomerId
INNER JOIN OrderStatuses s ON s.Id = o.StatusId
ORDER BY o.OrderDate DESC", conn))
                {
                    var dt = new DataTable();
                    da.Fill(dt);
                    _dgvOrders.DataSource = dt;
                    if (_dgvOrders.Columns["Id"] != null)
                        _dgvOrders.Columns["Id"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки заказов:\n" + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateOrderStatus(string statusName)
        {
            if (_dgvOrders.CurrentRow == null) return;
            var row = (_dgvOrders.CurrentRow.DataBoundItem as DataRowView)?.Row;
            if (row == null) return;

            int orderId = Convert.ToInt32(row["Id"]);
            try
            {
                using (var conn = new SqlConnection(_connectionString))
                {
                    conn.Open();
                    int statusId;
                    using (var cmdGet = new SqlCommand("SELECT Id FROM OrderStatuses WHERE Name = @name", conn))
                    {
                        cmdGet.Parameters.AddWithValue("@name", statusName);
                        var obj = cmdGet.ExecuteScalar();
                        if ((obj == null || obj == DBNull.Value) && statusName == "Доставлен")
                        {
                            cmdGet.Parameters["@name"].Value = "Выполнен";
                            obj = cmdGet.ExecuteScalar();
                        }
                        if (obj == null || obj == DBNull.Value)
                        {
                            MessageBox.Show("Статус \"" + statusName + "\" не найден в базе.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }

                        statusId = Convert.ToInt32(obj);
                    }

                    using (var cmd = new SqlCommand("UPDATE Orders SET StatusId = @sid WHERE Id = @id", conn))
                    {
                        cmd.Parameters.AddWithValue("@sid", statusId);
                        cmd.Parameters.AddWithValue("@id", orderId);
                        cmd.ExecuteNonQuery();
                    }
                }

                LoadOrders();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось обновить статус заказа:\n" + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CourierForm));
            this.SuspendLayout();
            // 
            // CourierForm
            // 
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(510, 392);
            this.Name = "CourierForm";
            this.ResumeLayout(false);

        }
    }
}
