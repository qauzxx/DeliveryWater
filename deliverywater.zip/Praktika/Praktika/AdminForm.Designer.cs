namespace Praktika
{
    partial class AdminForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.GroupBox groupBoxUsers;
        private System.Windows.Forms.DataGridView dgvUsers;
        private System.Windows.Forms.Panel panelButtons;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnBlockToggle;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label lblUsersSearch;
        private System.Windows.Forms.TextBox txtUsersSearch;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel statusLabel;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabUsers;
        private System.Windows.Forms.TabPage tabProducts;
        private System.Windows.Forms.TabPage tabOrders;
        private System.Windows.Forms.TabPage tabReports;
        private System.Windows.Forms.GroupBox groupReports;
        private System.Windows.Forms.DataGridView dgvReports;
        private System.Windows.Forms.Panel panelReports;
        private System.Windows.Forms.Label lblReportsSearch;
        private System.Windows.Forms.TextBox txtReportsSearch;
        private System.Windows.Forms.Button btnRptOrderCost;
        private System.Windows.Forms.Button btnRptInactiveCustomers;
        private System.Windows.Forms.Button btnRptPopularWaterType;
        private System.Windows.Forms.Button btnRptTopAddresses;
        private System.Windows.Forms.Button btnRptCourierMonthTotal;
        private System.Windows.Forms.GroupBox groupProducts;
        private System.Windows.Forms.DataGridView dgvProducts;
        private System.Windows.Forms.Panel panelProducts;
        private System.Windows.Forms.Button btnProductsRefresh;
        private System.Windows.Forms.Button btnProductAdd;
        private System.Windows.Forms.Button btnProductEdit;
        private System.Windows.Forms.Button btnProductDelete;
        private System.Windows.Forms.Label lblProductsSearch;
        private System.Windows.Forms.TextBox txtProductsSearch;
        private System.Windows.Forms.GroupBox groupOrders;
        private System.Windows.Forms.DataGridView dgvOrders;
        private System.Windows.Forms.Panel panelOrders;
        private System.Windows.Forms.Button btnOrdersRefresh;
        private System.Windows.Forms.Label lblOrderStatus;
        private System.Windows.Forms.ComboBox cmbOrderStatus;
        private System.Windows.Forms.Button btnOrderSaveStatus;
        private System.Windows.Forms.Label lblOrdersSearch;
        private System.Windows.Forms.TextBox txtOrdersSearch;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminForm));
            this.groupBoxUsers = new System.Windows.Forms.GroupBox();
            this.dgvUsers = new System.Windows.Forms.DataGridView();
            this.panelButtons = new System.Windows.Forms.Panel();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnBlockToggle = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.lblUsersSearch = new System.Windows.Forms.Label();
            this.txtUsersSearch = new System.Windows.Forms.TextBox();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.statusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabUsers = new System.Windows.Forms.TabPage();
            this.tabProducts = new System.Windows.Forms.TabPage();
            this.groupProducts = new System.Windows.Forms.GroupBox();
            this.dgvProducts = new System.Windows.Forms.DataGridView();
            this.panelProducts = new System.Windows.Forms.Panel();
            this.btnProductsRefresh = new System.Windows.Forms.Button();
            this.btnProductAdd = new System.Windows.Forms.Button();
            this.btnProductEdit = new System.Windows.Forms.Button();
            this.btnProductDelete = new System.Windows.Forms.Button();
            this.lblProductsSearch = new System.Windows.Forms.Label();
            this.txtProductsSearch = new System.Windows.Forms.TextBox();
            this.tabOrders = new System.Windows.Forms.TabPage();
            this.groupOrders = new System.Windows.Forms.GroupBox();
            this.dgvOrders = new System.Windows.Forms.DataGridView();
            this.panelOrders = new System.Windows.Forms.Panel();
            this.btnOrdersRefresh = new System.Windows.Forms.Button();
            this.lblOrderStatus = new System.Windows.Forms.Label();
            this.cmbOrderStatus = new System.Windows.Forms.ComboBox();
            this.btnOrderSaveStatus = new System.Windows.Forms.Button();
            this.lblOrdersSearch = new System.Windows.Forms.Label();
            this.txtOrdersSearch = new System.Windows.Forms.TextBox();
            this.tabReports = new System.Windows.Forms.TabPage();
            this.groupReports = new System.Windows.Forms.GroupBox();
            this.dgvReports = new System.Windows.Forms.DataGridView();
            this.panelReports = new System.Windows.Forms.Panel();
            this.lblReportsSearch = new System.Windows.Forms.Label();
            this.txtReportsSearch = new System.Windows.Forms.TextBox();
            this.btnRptCourierMonthTotal = new System.Windows.Forms.Button();
            this.btnRptTopAddresses = new System.Windows.Forms.Button();
            this.btnRptPopularWaterType = new System.Windows.Forms.Button();
            this.btnRptInactiveCustomers = new System.Windows.Forms.Button();
            this.btnRptOrderCost = new System.Windows.Forms.Button();
            this.groupBoxUsers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUsers)).BeginInit();
            this.panelButtons.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.tabControl.SuspendLayout();
            this.tabUsers.SuspendLayout();
            this.tabProducts.SuspendLayout();
            this.groupProducts.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProducts)).BeginInit();
            this.panelProducts.SuspendLayout();
            this.tabOrders.SuspendLayout();
            this.groupOrders.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrders)).BeginInit();
            this.panelOrders.SuspendLayout();
            this.tabReports.SuspendLayout();
            this.groupReports.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReports)).BeginInit();
            this.panelReports.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxUsers
            // 
            this.groupBoxUsers.Controls.Add(this.dgvUsers);
            this.groupBoxUsers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxUsers.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.groupBoxUsers.Location = new System.Drawing.Point(3, 3);
            this.groupBoxUsers.Name = "groupBoxUsers";
            this.groupBoxUsers.Size = new System.Drawing.Size(800, 397);
            this.groupBoxUsers.TabIndex = 0;
            this.groupBoxUsers.TabStop = false;
            this.groupBoxUsers.Text = "Пользователи";
            // 
            // dgvUsers
            // 
            this.dgvUsers.AllowUserToAddRows = false;
            this.dgvUsers.AllowUserToDeleteRows = false;
            this.dgvUsers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUsers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvUsers.Location = new System.Drawing.Point(3, 19);
            this.dgvUsers.Name = "dgvUsers";
            this.dgvUsers.Size = new System.Drawing.Size(794, 375);
            this.dgvUsers.TabIndex = 0;
            // 
            // panelButtons
            // 
            this.panelButtons.Controls.Add(this.btnRefresh);
            this.panelButtons.Controls.Add(this.btnSave);
            this.panelButtons.Controls.Add(this.btnAdd);
            this.panelButtons.Controls.Add(this.btnBlockToggle);
            this.panelButtons.Controls.Add(this.btnDelete);
            this.panelButtons.Controls.Add(this.btnBack);
            this.panelButtons.Controls.Add(this.lblUsersSearch);
            this.panelButtons.Controls.Add(this.txtUsersSearch);
            this.panelButtons.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelButtons.Location = new System.Drawing.Point(3, 400);
            this.panelButtons.Name = "panelButtons";
            this.panelButtons.Size = new System.Drawing.Size(800, 36);
            this.panelButtons.TabIndex = 1;
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(0, 6);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(100, 28);
            this.btnRefresh.TabIndex = 0;
            this.btnRefresh.Text = "Обновить";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(106, 6);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 28);
            this.btnSave.TabIndex = 1;
            this.btnSave.Text = "Сохранить";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(212, 6);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(100, 28);
            this.btnAdd.TabIndex = 2;
            this.btnAdd.Text = "Добавить";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnBlockToggle
            // 
            this.btnBlockToggle.Location = new System.Drawing.Point(318, 6);
            this.btnBlockToggle.Name = "btnBlockToggle";
            this.btnBlockToggle.Size = new System.Drawing.Size(120, 28);
            this.btnBlockToggle.TabIndex = 3;
            this.btnBlockToggle.Text = "Блок / Разблок";
            this.btnBlockToggle.UseVisualStyleBackColor = true;
            this.btnBlockToggle.Click += new System.EventHandler(this.btnBlockToggle_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(444, 6);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(100, 28);
            this.btnDelete.TabIndex = 4;
            this.btnDelete.Text = "Удалить";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnBack
            // 
            this.btnBack.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBack.Location = new System.Drawing.Point(707, 6);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(90, 28);
            this.btnBack.TabIndex = 5;
            this.btnBack.Text = "Назад";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // lblUsersSearch
            // 
            this.lblUsersSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblUsersSearch.AutoSize = true;
            this.lblUsersSearch.Location = new System.Drawing.Point(549, 12);
            this.lblUsersSearch.Name = "lblUsersSearch";
            this.lblUsersSearch.Size = new System.Drawing.Size(45, 13);
            this.lblUsersSearch.TabIndex = 6;
            this.lblUsersSearch.Text = "Поиск:";
            // 
            // txtUsersSearch
            // 
            this.txtUsersSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtUsersSearch.Location = new System.Drawing.Point(600, 9);
            this.txtUsersSearch.Name = "txtUsersSearch";
            this.txtUsersSearch.Size = new System.Drawing.Size(101, 20);
            this.txtUsersSearch.TabIndex = 7;
            this.txtUsersSearch.TextChanged += new System.EventHandler(this.txtUsersSearch_TextChanged);
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.statusLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 508);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(854, 22);
            this.statusStrip.SizingGrip = false;
            this.statusStrip.TabIndex = 2;
            // 
            // statusLabel
            // 
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(130, 17);
            this.statusLabel.Text = "Всего: 0  |  Активных: 0";
            // 
            // tabControl
            // 
            this.tabControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl.Controls.Add(this.tabUsers);
            this.tabControl.Controls.Add(this.tabProducts);
            this.tabControl.Controls.Add(this.tabOrders);
            this.tabControl.Controls.Add(this.tabReports);
            this.tabControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabControl.Location = new System.Drawing.Point(20, 20);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(814, 468);
            this.tabControl.TabIndex = 0;
            // 
            // tabUsers
            // 
            this.tabUsers.Controls.Add(this.groupBoxUsers);
            this.tabUsers.Controls.Add(this.panelButtons);
            this.tabUsers.Location = new System.Drawing.Point(4, 25);
            this.tabUsers.Name = "tabUsers";
            this.tabUsers.Padding = new System.Windows.Forms.Padding(3);
            this.tabUsers.Size = new System.Drawing.Size(806, 439);
            this.tabUsers.TabIndex = 0;
            this.tabUsers.Text = "Пользователи";
            this.tabUsers.UseVisualStyleBackColor = true;
            // 
            // tabProducts
            // 
            this.tabProducts.Controls.Add(this.groupProducts);
            this.tabProducts.Controls.Add(this.panelProducts);
            this.tabProducts.Location = new System.Drawing.Point(4, 25);
            this.tabProducts.Name = "tabProducts";
            this.tabProducts.Padding = new System.Windows.Forms.Padding(3);
            this.tabProducts.Size = new System.Drawing.Size(806, 439);
            this.tabProducts.TabIndex = 1;
            this.tabProducts.Text = "Каталог воды";
            this.tabProducts.UseVisualStyleBackColor = true;
            // 
            // groupProducts
            // 
            this.groupProducts.Controls.Add(this.dgvProducts);
            this.groupProducts.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupProducts.Location = new System.Drawing.Point(3, 3);
            this.groupProducts.Name = "groupProducts";
            this.groupProducts.Size = new System.Drawing.Size(800, 403);
            this.groupProducts.TabIndex = 0;
            this.groupProducts.TabStop = false;
            this.groupProducts.Text = "Позиции воды и аксессуары";
            // 
            // dgvProducts
            // 
            this.dgvProducts.AllowUserToAddRows = false;
            this.dgvProducts.AllowUserToDeleteRows = false;
            this.dgvProducts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProducts.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvProducts.Location = new System.Drawing.Point(3, 19);
            this.dgvProducts.Name = "dgvProducts";
            this.dgvProducts.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvProducts.Size = new System.Drawing.Size(794, 381);
            this.dgvProducts.TabIndex = 0;
            this.dgvProducts.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvProducts_CellDoubleClick);
            // 
            // panelProducts
            // 
            this.panelProducts.Controls.Add(this.btnProductsRefresh);
            this.panelProducts.Controls.Add(this.btnProductAdd);
            this.panelProducts.Controls.Add(this.btnProductEdit);
            this.panelProducts.Controls.Add(this.btnProductDelete);
            this.panelProducts.Controls.Add(this.lblProductsSearch);
            this.panelProducts.Controls.Add(this.txtProductsSearch);
            this.panelProducts.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelProducts.Location = new System.Drawing.Point(3, 406);
            this.panelProducts.Name = "panelProducts";
            this.panelProducts.Size = new System.Drawing.Size(800, 30);
            this.panelProducts.TabIndex = 1;
            // 
            // btnProductsRefresh
            // 
            this.btnProductsRefresh.Location = new System.Drawing.Point(0, 4);
            this.btnProductsRefresh.Name = "btnProductsRefresh";
            this.btnProductsRefresh.Size = new System.Drawing.Size(90, 28);
            this.btnProductsRefresh.TabIndex = 0;
            this.btnProductsRefresh.Text = "Обновить";
            this.btnProductsRefresh.UseVisualStyleBackColor = true;
            this.btnProductsRefresh.Click += new System.EventHandler(this.btnProductsRefresh_Click);
            // 
            // btnProductAdd
            // 
            this.btnProductAdd.Location = new System.Drawing.Point(96, 4);
            this.btnProductAdd.Name = "btnProductAdd";
            this.btnProductAdd.Size = new System.Drawing.Size(90, 28);
            this.btnProductAdd.TabIndex = 1;
            this.btnProductAdd.Text = "Добавить";
            this.btnProductAdd.UseVisualStyleBackColor = true;
            this.btnProductAdd.Click += new System.EventHandler(this.btnProductAdd_Click);
            // 
            // btnProductEdit
            // 
            this.btnProductEdit.Location = new System.Drawing.Point(192, 4);
            this.btnProductEdit.Name = "btnProductEdit";
            this.btnProductEdit.Size = new System.Drawing.Size(90, 28);
            this.btnProductEdit.TabIndex = 2;
            this.btnProductEdit.Text = "Изменить";
            this.btnProductEdit.UseVisualStyleBackColor = true;
            this.btnProductEdit.Click += new System.EventHandler(this.btnProductEdit_Click);
            // 
            // btnProductDelete
            // 
            this.btnProductDelete.Location = new System.Drawing.Point(288, 4);
            this.btnProductDelete.Name = "btnProductDelete";
            this.btnProductDelete.Size = new System.Drawing.Size(90, 28);
            this.btnProductDelete.TabIndex = 3;
            this.btnProductDelete.Text = "Удалить";
            this.btnProductDelete.UseVisualStyleBackColor = true;
            this.btnProductDelete.Click += new System.EventHandler(this.btnProductDelete_Click);
            // 
            // lblProductsSearch
            // 
            this.lblProductsSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblProductsSearch.AutoSize = true;
            this.lblProductsSearch.Location = new System.Drawing.Point(579, 10);
            this.lblProductsSearch.Name = "lblProductsSearch";
            this.lblProductsSearch.Size = new System.Drawing.Size(53, 17);
            this.lblProductsSearch.TabIndex = 4;
            this.lblProductsSearch.Text = "Поиск:";
            // 
            // txtProductsSearch
            // 
            this.txtProductsSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtProductsSearch.Location = new System.Drawing.Point(638, 6);
            this.txtProductsSearch.Name = "txtProductsSearch";
            this.txtProductsSearch.Size = new System.Drawing.Size(158, 23);
            this.txtProductsSearch.TabIndex = 5;
            this.txtProductsSearch.TextChanged += new System.EventHandler(this.txtProductsSearch_TextChanged);
            // 
            // tabOrders
            // 
            this.tabOrders.Controls.Add(this.groupOrders);
            this.tabOrders.Controls.Add(this.panelOrders);
            this.tabOrders.Location = new System.Drawing.Point(4, 25);
            this.tabOrders.Name = "tabOrders";
            this.tabOrders.Size = new System.Drawing.Size(806, 439);
            this.tabOrders.TabIndex = 2;
            this.tabOrders.Text = "Заказы";
            this.tabOrders.UseVisualStyleBackColor = true;
            // 
            // groupOrders
            // 
            this.groupOrders.Controls.Add(this.dgvOrders);
            this.groupOrders.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupOrders.Location = new System.Drawing.Point(0, 0);
            this.groupOrders.Name = "groupOrders";
            this.groupOrders.Size = new System.Drawing.Size(806, 409);
            this.groupOrders.TabIndex = 0;
            this.groupOrders.TabStop = false;
            this.groupOrders.Text = "Список заказов";
            // 
            // dgvOrders
            // 
            this.dgvOrders.AllowUserToAddRows = false;
            this.dgvOrders.AllowUserToDeleteRows = false;
            this.dgvOrders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOrders.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvOrders.Location = new System.Drawing.Point(3, 19);
            this.dgvOrders.Name = "dgvOrders";
            this.dgvOrders.ReadOnly = true;
            this.dgvOrders.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvOrders.Size = new System.Drawing.Size(800, 387);
            this.dgvOrders.TabIndex = 0;
            this.dgvOrders.SelectionChanged += new System.EventHandler(this.dgvOrders_SelectionChanged);
            // 
            // panelOrders
            // 
            this.panelOrders.Controls.Add(this.btnOrdersRefresh);
            this.panelOrders.Controls.Add(this.lblOrderStatus);
            this.panelOrders.Controls.Add(this.cmbOrderStatus);
            this.panelOrders.Controls.Add(this.btnOrderSaveStatus);
            this.panelOrders.Controls.Add(this.lblOrdersSearch);
            this.panelOrders.Controls.Add(this.txtOrdersSearch);
            this.panelOrders.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelOrders.Location = new System.Drawing.Point(0, 409);
            this.panelOrders.Name = "panelOrders";
            this.panelOrders.Size = new System.Drawing.Size(806, 30);
            this.panelOrders.TabIndex = 1;
            // 
            // btnOrdersRefresh
            // 
            this.btnOrdersRefresh.Location = new System.Drawing.Point(0, 4);
            this.btnOrdersRefresh.Name = "btnOrdersRefresh";
            this.btnOrdersRefresh.Size = new System.Drawing.Size(90, 28);
            this.btnOrdersRefresh.TabIndex = 0;
            this.btnOrdersRefresh.Text = "Обновить";
            this.btnOrdersRefresh.UseVisualStyleBackColor = true;
            this.btnOrdersRefresh.Click += new System.EventHandler(this.btnOrdersRefresh_Click);
            // 
            // lblOrderStatus
            // 
            this.lblOrderStatus.AutoSize = true;
            this.lblOrderStatus.Location = new System.Drawing.Point(96, 10);
            this.lblOrderStatus.Name = "lblOrderStatus";
            this.lblOrderStatus.Size = new System.Drawing.Size(57, 17);
            this.lblOrderStatus.TabIndex = 1;
            this.lblOrderStatus.Text = "Статус:";
            // 
            // cmbOrderStatus
            // 
            this.cmbOrderStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbOrderStatus.FormattingEnabled = true;
            this.cmbOrderStatus.Location = new System.Drawing.Point(146, 6);
            this.cmbOrderStatus.Name = "cmbOrderStatus";
            this.cmbOrderStatus.Size = new System.Drawing.Size(180, 24);
            this.cmbOrderStatus.TabIndex = 2;
            // 
            // btnOrderSaveStatus
            // 
            this.btnOrderSaveStatus.Location = new System.Drawing.Point(332, 4);
            this.btnOrderSaveStatus.Name = "btnOrderSaveStatus";
            this.btnOrderSaveStatus.Size = new System.Drawing.Size(120, 28);
            this.btnOrderSaveStatus.TabIndex = 3;
            this.btnOrderSaveStatus.Text = "Сохранить статус";
            this.btnOrderSaveStatus.UseVisualStyleBackColor = true;
            this.btnOrderSaveStatus.Click += new System.EventHandler(this.btnOrderSaveStatus_Click);
            // 
            // lblOrdersSearch
            // 
            this.lblOrdersSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblOrdersSearch.AutoSize = true;
            this.lblOrdersSearch.Location = new System.Drawing.Point(540, 10);
            this.lblOrdersSearch.Name = "lblOrdersSearch";
            this.lblOrdersSearch.Size = new System.Drawing.Size(53, 17);
            this.lblOrdersSearch.TabIndex = 4;
            this.lblOrdersSearch.Text = "Поиск:";
            // 
            // txtOrdersSearch
            // 
            this.txtOrdersSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtOrdersSearch.Location = new System.Drawing.Point(599, 6);
            this.txtOrdersSearch.Name = "txtOrdersSearch";
            this.txtOrdersSearch.Size = new System.Drawing.Size(202, 23);
            this.txtOrdersSearch.TabIndex = 5;
            this.txtOrdersSearch.TextChanged += new System.EventHandler(this.txtOrdersSearch_TextChanged);
            // 
            // tabReports
            // 
            this.tabReports.Controls.Add(this.groupReports);
            this.tabReports.Controls.Add(this.panelReports);
            this.tabReports.Location = new System.Drawing.Point(4, 25);
            this.tabReports.Name = "tabReports";
            this.tabReports.Padding = new System.Windows.Forms.Padding(3);
            this.tabReports.Size = new System.Drawing.Size(806, 439);
            this.tabReports.TabIndex = 3;
            this.tabReports.Text = "Отчёты";
            this.tabReports.UseVisualStyleBackColor = true;
            // 
            // groupReports
            // 
            this.groupReports.Controls.Add(this.dgvReports);
            this.groupReports.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupReports.Location = new System.Drawing.Point(3, 39);
            this.groupReports.Name = "groupReports";
            this.groupReports.Size = new System.Drawing.Size(800, 397);
            this.groupReports.TabIndex = 1;
            this.groupReports.TabStop = false;
            this.groupReports.Text = "Результат";
            // 
            // dgvReports
            // 
            this.dgvReports.AllowUserToAddRows = false;
            this.dgvReports.AllowUserToDeleteRows = false;
            this.dgvReports.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvReports.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvReports.Location = new System.Drawing.Point(3, 19);
            this.dgvReports.Name = "dgvReports";
            this.dgvReports.ReadOnly = true;
            this.dgvReports.Size = new System.Drawing.Size(794, 375);
            this.dgvReports.TabIndex = 0;
            // 
            // panelReports
            // 
            this.panelReports.Controls.Add(this.lblReportsSearch);
            this.panelReports.Controls.Add(this.txtReportsSearch);
            this.panelReports.Controls.Add(this.btnRptCourierMonthTotal);
            this.panelReports.Controls.Add(this.btnRptTopAddresses);
            this.panelReports.Controls.Add(this.btnRptPopularWaterType);
            this.panelReports.Controls.Add(this.btnRptInactiveCustomers);
            this.panelReports.Controls.Add(this.btnRptOrderCost);
            this.panelReports.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelReports.Location = new System.Drawing.Point(3, 3);
            this.panelReports.Name = "panelReports";
            this.panelReports.Size = new System.Drawing.Size(800, 36);
            this.panelReports.TabIndex = 0;
            // 
            // lblReportsSearch
            // 
            this.lblReportsSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblReportsSearch.AutoSize = true;
            this.lblReportsSearch.Location = new System.Drawing.Point(504, 10);
            this.lblReportsSearch.Name = "lblReportsSearch";
            this.lblReportsSearch.Size = new System.Drawing.Size(53, 17);
            this.lblReportsSearch.TabIndex = 5;
            this.lblReportsSearch.Text = "Поиск:";
            // 
            // txtReportsSearch
            // 
            this.txtReportsSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtReportsSearch.Location = new System.Drawing.Point(563, 6);
            this.txtReportsSearch.Name = "txtReportsSearch";
            this.txtReportsSearch.Size = new System.Drawing.Size(234, 23);
            this.txtReportsSearch.TabIndex = 6;
            this.txtReportsSearch.TextChanged += new System.EventHandler(this.txtReportsSearch_TextChanged);
            // 
            // btnRptCourierMonthTotal
            // 
            this.btnRptCourierMonthTotal.Location = new System.Drawing.Point(399, 5);
            this.btnRptCourierMonthTotal.Name = "btnRptCourierMonthTotal";
            this.btnRptCourierMonthTotal.Size = new System.Drawing.Size(100, 28);
            this.btnRptCourierMonthTotal.TabIndex = 4;
            this.btnRptCourierMonthTotal.Text = "Курьер за месяц";
            this.btnRptCourierMonthTotal.UseVisualStyleBackColor = true;
            this.btnRptCourierMonthTotal.Click += new System.EventHandler(this.btnRptCourierMonthTotal_Click);
            // 
            // btnRptTopAddresses
            // 
            this.btnRptTopAddresses.Location = new System.Drawing.Point(302, 5);
            this.btnRptTopAddresses.Name = "btnRptTopAddresses";
            this.btnRptTopAddresses.Size = new System.Drawing.Size(95, 28);
            this.btnRptTopAddresses.TabIndex = 3;
            this.btnRptTopAddresses.Text = "Топ адресов";
            this.btnRptTopAddresses.UseVisualStyleBackColor = true;
            this.btnRptTopAddresses.Click += new System.EventHandler(this.btnRptTopAddresses_Click);
            // 
            // btnRptPopularWaterType
            // 
            this.btnRptPopularWaterType.Location = new System.Drawing.Point(201, 5);
            this.btnRptPopularWaterType.Name = "btnRptPopularWaterType";
            this.btnRptPopularWaterType.Size = new System.Drawing.Size(95, 28);
            this.btnRptPopularWaterType.TabIndex = 2;
            this.btnRptPopularWaterType.Text = "Популярный объём";
            this.btnRptPopularWaterType.UseVisualStyleBackColor = true;
            this.btnRptPopularWaterType.Click += new System.EventHandler(this.btnRptPopularWaterType_Click);
            // 
            // btnRptInactiveCustomers
            // 
            this.btnRptInactiveCustomers.Location = new System.Drawing.Point(100, 5);
            this.btnRptInactiveCustomers.Name = "btnRptInactiveCustomers";
            this.btnRptInactiveCustomers.Size = new System.Drawing.Size(95, 28);
            this.btnRptInactiveCustomers.TabIndex = 1;
            this.btnRptInactiveCustomers.Text = "Без заказов";
            this.btnRptInactiveCustomers.UseVisualStyleBackColor = true;
            this.btnRptInactiveCustomers.Click += new System.EventHandler(this.btnRptInactiveCustomers_Click);
            // 
            // btnRptOrderCost
            // 
            this.btnRptOrderCost.Location = new System.Drawing.Point(0, 5);
            this.btnRptOrderCost.Name = "btnRptOrderCost";
            this.btnRptOrderCost.Size = new System.Drawing.Size(95, 28);
            this.btnRptOrderCost.TabIndex = 0;
            this.btnRptOrderCost.Text = "Сумма заказов";
            this.btnRptOrderCost.UseVisualStyleBackColor = true;
            this.btnRptOrderCost.Click += new System.EventHandler(this.btnRptOrderCost_Click);
            // 
            // AdminForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(854, 530);
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.statusStrip);
            this.MinimumSize = new System.Drawing.Size(550, 380);
            this.Name = "AdminForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Администрирование — Сервис доставки воды";
            this.groupBoxUsers.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvUsers)).EndInit();
            this.panelButtons.ResumeLayout(false);
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.tabControl.ResumeLayout(false);
            this.tabUsers.ResumeLayout(false);
            this.tabProducts.ResumeLayout(false);
            this.groupProducts.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvProducts)).EndInit();
            this.panelProducts.ResumeLayout(false);
            this.tabOrders.ResumeLayout(false);
            this.groupOrders.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrders)).EndInit();
            this.panelOrders.ResumeLayout(false);
            this.panelOrders.PerformLayout();
            this.tabReports.ResumeLayout(false);
            this.groupReports.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvReports)).EndInit();
            this.panelReports.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}
