﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Praktika
{
    public partial class AdminForm : Form
    {
        private readonly string _connectionString;
        private DataTable _table;

        public AdminForm()
        {
            InitializeComponent();
            _connectionString = DatabaseHelper.GetConnectionString();
            if (string.IsNullOrWhiteSpace(_connectionString))
            {
                MessageBox.Show("Не найдена строка подключения DeliveryWater.", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                Close();
                return;
            }

            LoadUsers();
            UpdateStatus();
            LoadProducts();
            LoadOrders();
            LoadOrderStatuses();

            dgvUsers.CurrentCellDirtyStateChanged += dgvUsers_CurrentCellDirtyStateChanged;
            dgvUsers.CellValueChanged += dgvUsers_CellValueChanged;
        }

        private void ShowReport(string sql, params SqlParameter[] parameters)
        {
            try
            {
                using (var conn = new SqlConnection(_connectionString))
                using (var da = new SqlDataAdapter(sql, conn))
                {
                    if (parameters != null && parameters.Length > 0)
                        da.SelectCommand.Parameters.AddRange(parameters);
                    var dt = new DataTable();
                    da.Fill(dt);
                    dgvReports.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка выполнения отчёта:\n" + ex.Message, "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRptOrderCost_Click(object sender, EventArgs e)
        {
            ShowReport(@"
SELECT 
    o.Id AS [Заказ],
    o.OrderDate AS [Дата],
    c.FullName AS [Клиент],
    SUM(ISNULL(oi.Quantity, 0) * ISNULL(oi.UnitPrice, 0)) AS [Сумма товаров],
    CAST(200 AS DECIMAL(18,2)) AS [Доставка],
    SUM(ISNULL(oi.Quantity, 0) * ISNULL(oi.UnitPrice, 0)) + 200 AS [Итого]
FROM Orders o
INNER JOIN Customers c ON c.Id = o.CustomerId
LEFT JOIN OrderItems oi ON oi.OrderId = o.Id
GROUP BY o.Id, o.OrderDate, c.FullName
ORDER BY o.OrderDate DESC;");
        }

        private void btnRptInactiveCustomers_Click(object sender, EventArgs e)
        {
            ShowReport(@"
SELECT 
    c.Id,
    c.FullName AS [Клиент],
    c.Email AS [Email],
    c.Phone AS [Телефон],
    MAX(o.OrderDate) AS [Последний заказ]
FROM Customers c
LEFT JOIN Orders o ON o.CustomerId = c.Id
GROUP BY c.Id, c.FullName, c.Email, c.Phone
HAVING MAX(o.OrderDate) IS NULL OR MAX(o.OrderDate) < DATEADD(DAY, -30, GETDATE())
ORDER BY [Последний заказ];");
        }

        private void btnRptPopularWaterType_Click(object sender, EventArgs e)
        {
            ShowReport(@"
WITH OrderTypes AS (
    SELECT DISTINCT
        oi.OrderId,
        ISNULL(v.VolumeLabel, c.Name) AS WaterType
    FROM OrderItems oi
    INNER JOIN Products p ON p.Id = oi.ProductId
    INNER JOIN Categories c ON c.Id = p.CategoryId
    OUTER APPLY (
        SELECT
            CASE
                WHEN PATINDEX(N'%[0-9]%', x.Src) = 0 THEN NULL
                ELSE
                    REPLACE(
                        LEFT(
                            SUBSTRING(x.Src, PATINDEX(N'%[0-9]%', x.Src), 32),
                            NULLIF(PATINDEX(N'%[^0-9.,]%', SUBSTRING(x.Src, PATINDEX(N'%[0-9]%', x.Src), 32) + N' '), 0) - 1
                        ),
                        N',', N'.'
                    ) + N' л'
            END AS VolumeLabel
        FROM (VALUES (p.Name), (c.Name), (ISNULL(p.Article, N''))) x(Src)
        WHERE x.Src LIKE N'%л%' OR x.Src LIKE N'%литр%'
    ) v
)
SELECT TOP 1
    WaterType AS [Тип воды],
    COUNT(*) AS [Кол-во заказов]
FROM OrderTypes
GROUP BY WaterType
ORDER BY COUNT(*) DESC;");
        }

        private void btnRptTopAddresses_Click(object sender, EventArgs e)
        {
            ShowReport(@"
SELECT TOP 5
    DeliveryAddress AS [Адрес],
    COUNT(*) AS [Доставок]
FROM Orders
WHERE DeliveryAddress IS NOT NULL AND LTRIM(RTRIM(DeliveryAddress)) <> ''
GROUP BY DeliveryAddress
ORDER BY COUNT(*) DESC;");
        }

        private void LoadUsers()
        {
            try
            {
                using (var conn = new SqlConnection(_connectionString))
                using (var da = new SqlDataAdapter("SELECT Id, Username, Password, ISNULL(IsActive, 1) AS IsActive FROM Users ORDER BY Id", conn))
                {
                    _table = new DataTable();
                    da.Fill(_table);
                    dgvUsers.DataSource = _table;
                    ConfigureGrid();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки пользователей:\n" + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ConfigureGrid()
        {
            if (dgvUsers.Columns.Count == 0) return;

            dgvUsers.AutoGenerateColumns = true;
            dgvUsers.AllowUserToAddRows = false;
            dgvUsers.AllowUserToDeleteRows = false;
            dgvUsers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvUsers.MultiSelect = true;
            dgvUsers.ReadOnly = false;
            dgvUsers.RowHeadersVisible = true;
            dgvUsers.BorderStyle = BorderStyle.FixedSingle;
            dgvUsers.BackgroundColor = System.Drawing.SystemColors.Window;
            dgvUsers.EnableHeadersVisualStyles = true;
            dgvUsers.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(240, 240, 240);
            dgvUsers.ColumnHeadersHeight = 28;
            dgvUsers.RowTemplate.Height = 24;
            dgvUsers.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(248, 248, 248);

            if (dgvUsers.Columns["Id"] != null)
            {
                dgvUsers.Columns["Id"].HeaderText = "ID";
                dgvUsers.Columns["Id"].ReadOnly = true;
                dgvUsers.Columns["Id"].Width = 50;
            }
            if (dgvUsers.Columns["Username"] != null)
            {
                dgvUsers.Columns["Username"].HeaderText = "Логин";
                dgvUsers.Columns["Username"].Width = 150;
            }
            if (dgvUsers.Columns["Password"] != null)
            {
                dgvUsers.Columns["Password"].HeaderText = "Пароль";
                dgvUsers.Columns["Password"].Width = 120;
            }
            if (dgvUsers.Columns["IsActive"] != null)
            {
                dgvUsers.Columns["IsActive"].HeaderText = "Активен";
                dgvUsers.Columns["IsActive"].Width = 70;
                dgvUsers.Columns["IsActive"].ReadOnly = false;
            }
        }

        private void dgvUsers_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        {
            if (dgvUsers.IsCurrentCellDirty)
                dgvUsers.CommitEdit(DataGridViewDataErrorContexts.Commit);
        }

        private void dgvUsers_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0 || dgvUsers.Columns["IsActive"] == null)
                return;
            if (e.ColumnIndex != dgvUsers.Columns["IsActive"].Index)
                return;

            var row = (dgvUsers.Rows[e.RowIndex].DataBoundItem as DataRowView)?.Row;
            if (row == null) return;

            var username = row["Username"]?.ToString() ?? string.Empty;
            if (string.Equals(username, "admin", StringComparison.OrdinalIgnoreCase))
            {
                row["IsActive"] = true;
                MessageBox.Show("Учётную запись admin нельзя заблокировать.", "Ограничение",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            SaveIsActiveImmediately(row);
            UpdateStatus();
        }

        private void UpdateStatus()
        {
            int total = _table?.Rows?.Count ?? 0;
            int active = 0;
            if (_table != null)
            {
                foreach (DataRow r in _table.Rows)
                {
                    if (r.RowState != DataRowState.Deleted && !r.IsNull("IsActive") && Convert.ToBoolean(r["IsActive"]))
                        active++;
                }
            }
            statusLabel.Text = string.Format("Всего: {0}  |  Активных: {1}", total, active);
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadUsers();
            UpdateStatus();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (_table == null) return;
            var row = _table.NewRow();
            row["Username"] = "new_user";
            row["Password"] = "1234";
            row["IsActive"] = true;
            _table.Rows.Add(row);
            UpdateStatus();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (_table == null) return;
            if (dgvUsers.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите пользователя для удаления.", "Подсказка", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            var result = MessageBox.Show("Удалить выбранных пользователей?", "Подтверждение",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result != DialogResult.Yes) return;

            foreach (DataGridViewRow gridRow in dgvUsers.SelectedRows)
            {
                if (gridRow.DataBoundItem is DataRowView view)
                {
                    var username = view.Row["Username"]?.ToString() ?? "";
                    if (string.Equals(username, "admin", StringComparison.OrdinalIgnoreCase)
                        || string.Equals(username, "kura", StringComparison.OrdinalIgnoreCase))
                    {
                        MessageBox.Show("Нельзя удалить служебную учётную запись (admin/kura).", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        continue;
                    }
                    view.Row.Delete();
                }
            }
            UpdateStatus();
        }

        private void btnBlockToggle_Click(object sender, EventArgs e)
        {
            if (_table == null || dgvUsers.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите пользователя для блокировки или разблокировки.", "Подсказка", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var blocked = new System.Collections.Generic.List<string>();
            var unblocked = new System.Collections.Generic.List<string>();

            foreach (DataGridViewRow gridRow in dgvUsers.SelectedRows)
            {
                if (gridRow.DataBoundItem is DataRowView view)
                {
                    var username = view.Row["Username"]?.ToString() ?? "";
                    if (string.Equals(username, "admin", StringComparison.OrdinalIgnoreCase)
                        || string.Equals(username, "kura", StringComparison.OrdinalIgnoreCase))
                    {
                        MessageBox.Show("Нельзя заблокировать служебную учётную запись (admin/kura).", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        continue;
                    }
                    var current = view.Row["IsActive"];
                    var isActive = current is bool b ? b : !(current is DBNull) && Convert.ToBoolean(current);
                    view.Row["IsActive"] = !isActive;
                    SaveIsActiveImmediately(view.Row);
                    if (isActive)
                        blocked.Add(username);
                    else
                        unblocked.Add(username);
                }
            }

            if (blocked.Count > 0)
                MessageBox.Show("Пользователь(и) заблокированы: " + string.Join(", ", blocked) + ".", "Блокировка", MessageBoxButtons.OK, MessageBoxIcon.Information);
            if (unblocked.Count > 0)
                MessageBox.Show("Пользователь(и) разблокированы: " + string.Join(", ", unblocked) + ".", "Разблокировка", MessageBoxButtons.OK, MessageBoxIcon.Information);

            UpdateStatus();
        }

        private void SaveIsActiveImmediately(DataRow row)
        {
            if (row == null || row.RowState == DataRowState.Deleted || row["Id"] == DBNull.Value) return;

            try
            {
                using (var conn = new SqlConnection(_connectionString))
                using (var cmd = new SqlCommand("UPDATE Users SET IsActive=@a WHERE Id=@id", conn))
                {
                    conn.Open();
                    cmd.Parameters.AddWithValue("@a", row["IsActive"]);
                    cmd.Parameters.AddWithValue("@id", row["Id"]);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось сохранить статус пользователя:\n" + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (_table == null) return;

            try
            {
                using (var conn = new SqlConnection(_connectionString))
                {
                    conn.Open();

                    foreach (DataRow row in _table.Rows)
                    {
                        if (row.RowState == DataRowState.Added)
                        {
                            var username = Convert.ToString(row["Username"]) ?? string.Empty;
                            var isAdmin = string.Equals(username, "admin", StringComparison.OrdinalIgnoreCase);
                            using (var cmd = new SqlCommand(
                                       "INSERT INTO Users (Username, Password, IsActive) VALUES (@u, @p, @a); SELECT SCOPE_IDENTITY();",
                                       conn))
                            {
                                cmd.Parameters.AddWithValue("@u", row["Username"]);
                                cmd.Parameters.AddWithValue("@p", row["Password"]);
                                cmd.Parameters.AddWithValue("@a", isAdmin ? (object)true : row["IsActive"]);
                                var id = Convert.ToInt32(cmd.ExecuteScalar());
                                row["Id"] = id;
                            }
                        }
                        else if (row.RowState == DataRowState.Modified)
                        {
                            var username = Convert.ToString(row["Username"]) ?? string.Empty;
                            var isAdmin = string.Equals(username, "admin", StringComparison.OrdinalIgnoreCase);
                            using (var cmd = new SqlCommand(
                                       "UPDATE Users SET Username=@u, Password=@p, IsActive=@a WHERE Id=@id", conn))
                            {
                                cmd.Parameters.AddWithValue("@u", row["Username"]);
                                cmd.Parameters.AddWithValue("@p", row["Password"]);
                                cmd.Parameters.AddWithValue("@a", isAdmin ? (object)true : row["IsActive"]);
                                cmd.Parameters.AddWithValue("@id", row["Id"]);
                                cmd.ExecuteNonQuery();
                            }
                        }
                        else if (row.RowState == DataRowState.Deleted)
                        {
                            using (var cmd = new SqlCommand("DELETE FROM Users WHERE Id=@id", conn))
                            {
                                cmd.Parameters.AddWithValue("@id", row["Id", DataRowVersion.Original]);
                                cmd.ExecuteNonQuery();
                            }
                        }
                    }
                }

                _table.AcceptChanges();
                UpdateStatus();
                MessageBox.Show("Изменения сохранены.", "Успех",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения изменений:\n" + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            if (_table != null && _table.GetChanges() != null)
            {
                var result = MessageBox.Show("Есть несохранённые изменения. Вернуться без сохранения?",
                    "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result != DialogResult.Yes) return;
            }
            Close();
        }

        // --- Товары ---
        private void LoadProducts()
        {
            try
            {
                using (var conn = new SqlConnection(_connectionString))
                using (var da = new SqlDataAdapter(
                    @"SELECT p.Id, p.Name AS [Название], c.Name AS [Категория], m.Name AS [Производитель], p.Price AS [Цена (₽)], p.StockQuantity AS [В наличии]
FROM Products p
INNER JOIN Categories c ON c.Id = p.CategoryId
INNER JOIN Manufacturers m ON m.Id = p.ManufacturerId
ORDER BY p.Name", conn))
                {
                    var dt = new DataTable();
                    da.Fill(dt);
                    dgvProducts.DataSource = dt;
                    if (dgvProducts.Columns["Id"] != null) dgvProducts.Columns["Id"].Visible = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки каталога воды. Проверьте таблицы Products, Categories, Manufacturers.\n" + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnProductsRefresh_Click(object sender, EventArgs e) => LoadProducts();

        private void btnProductAdd_Click(object sender, EventArgs e)
        {
            using (var f = new ProductEditForm(_connectionString) { ProductId = null })
            {
                if (f.ShowDialog() != DialogResult.OK) return;
                try
                {
                    using (var conn = new SqlConnection(_connectionString))
                    {
                        conn.Open();
                        using (var cmd = new SqlCommand(
                            "INSERT INTO Products (CategoryId, ManufacturerId, Name, Price, StockQuantity, IsActive) VALUES (@cid, @mid, @name, @price, @stock, 1)", conn))
                        {
                            cmd.Parameters.AddWithValue("@cid", f.CategoryId);
                            cmd.Parameters.AddWithValue("@mid", f.ManufacturerId);
                            cmd.Parameters.AddWithValue("@name", f.ProductName);
                            cmd.Parameters.AddWithValue("@price", f.Price);
                            cmd.Parameters.AddWithValue("@stock", f.Stock);
                            cmd.ExecuteNonQuery();
                        }
                    }
                    LoadProducts();
                    MessageBox.Show("Позиция воды добавлена.", "Каталог воды", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка добавления позиции:\n" + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnProductEdit_Click(object sender, EventArgs e)
        {
            if (dgvProducts.CurrentRow == null)
            {
                MessageBox.Show("Выберите товар для редактирования.", "Каталог воды", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            var row = (dgvProducts.CurrentRow.DataBoundItem as DataRowView)?.Row;
            if (row == null) return;
            int id = Convert.ToInt32(row["Id"]);
            using (var f = new ProductEditForm(_connectionString) { ProductId = id })
            {
                if (f.ShowDialog() != DialogResult.OK) return;
                try
                {
                    using (var conn = new SqlConnection(_connectionString))
                    {
                        conn.Open();
                        using (var cmd = new SqlCommand(
                            "UPDATE Products SET Name=@name, CategoryId=@cid, ManufacturerId=@mid, Price=@price, StockQuantity=@stock, UpdatedAt=GETDATE() WHERE Id=@id", conn))
                        {
                            cmd.Parameters.AddWithValue("@name", f.ProductName);
                            cmd.Parameters.AddWithValue("@cid", f.CategoryId);
                            cmd.Parameters.AddWithValue("@mid", f.ManufacturerId);
                            cmd.Parameters.AddWithValue("@price", f.Price);
                            cmd.Parameters.AddWithValue("@stock", f.Stock);
                            cmd.Parameters.AddWithValue("@id", id);
                            cmd.ExecuteNonQuery();
                        }
                    }
                    LoadProducts();
                    MessageBox.Show("Позиция воды сохранена.", "Каталог воды", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка сохранения:\n" + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnProductDelete_Click(object sender, EventArgs e)
        {
            if (dgvProducts.CurrentRow == null)
            {
                MessageBox.Show("Выберите товар для удаления.", "Каталог воды", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            var row = (dgvProducts.CurrentRow.DataBoundItem as DataRowView)?.Row;
            if (row == null) return;
            if (MessageBox.Show("Удалить товар \"" + row["Название"] + "\"?", "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;
            try
            {
                int id = Convert.ToInt32(row["Id"]);
                using (var conn = new SqlConnection(_connectionString))
                {
                    conn.Open();
                    using (var cmd = new SqlCommand("DELETE FROM Products WHERE Id = @id", conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.ExecuteNonQuery();
                    }
                }
                LoadProducts();
                    MessageBox.Show("Позиция воды удалена.", "Каталог воды", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка удаления (возможно, позиция есть в заказах):\n" + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvProducts_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
                btnProductEdit_Click(sender, EventArgs.Empty);
        }

        // --- Заказы ---
        private DataTable _ordersTable;

        private void LoadOrderStatuses()
        {
            cmbOrderStatus.Items.Clear();
            try
            {
                using (var conn = new SqlConnection(_connectionString))
                {
                    conn.Open();
                    using (var cmd = new SqlCommand("SELECT Id, Name FROM OrderStatuses ORDER BY Id", conn))
                    using (var r = cmd.ExecuteReader())
                        while (r.Read())
                            cmbOrderStatus.Items.Add(new OrderStatusItem(r.GetInt32(0), r.GetString(1)));
                }
                if (cmbOrderStatus.Items.Count > 0) cmbOrderStatus.SelectedIndex = 0;
            }
            catch { }
        }

        private void LoadOrders()
        {
            try
            {
                using (var conn = new SqlConnection(_connectionString))
                using (var da = new SqlDataAdapter(
                    @"SELECT o.Id, c.FullName AS [Клиент], o.OrderDate AS [Дата], o.TotalAmount AS [Сумма], s.Name AS [Статус], o.StatusId
FROM Orders o
INNER JOIN Customers c ON c.Id = o.CustomerId
INNER JOIN OrderStatuses s ON s.Id = o.StatusId
ORDER BY o.OrderDate DESC", conn))
                {
                    _ordersTable = new DataTable();
                    da.Fill(_ordersTable);
                    dgvOrders.DataSource = _ordersTable;
                    if (dgvOrders.Columns["StatusId"] != null) dgvOrders.Columns["StatusId"].Visible = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки заказов. Проверьте таблицы Orders, Customers, OrderStatuses.\n" + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnOrdersRefresh_Click(object sender, EventArgs e) => LoadOrders();

        private void dgvOrders_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvOrders.CurrentRow == null || _ordersTable == null) return;
            var row = (dgvOrders.CurrentRow.DataBoundItem as DataRowView)?.Row;
            if (row == null || row.IsNull("StatusId")) return;
            int statusId = Convert.ToInt32(row["StatusId"]);
            for (int i = 0; i < cmbOrderStatus.Items.Count; i++)
            {
                if ((cmbOrderStatus.Items[i] as OrderStatusItem)?.Id == statusId)
                {
                    cmbOrderStatus.SelectedIndex = i;
                    break;
                }
            }
        }

        private void btnOrderSaveStatus_Click(object sender, EventArgs e)
        {
            if (dgvOrders.CurrentRow == null || cmbOrderStatus.SelectedItem == null) return;
            var row = (dgvOrders.CurrentRow.DataBoundItem as DataRowView)?.Row;
            if (row == null) return;
            int orderId = Convert.ToInt32(row["Id"]);
            int statusId = (cmbOrderStatus.SelectedItem as OrderStatusItem)?.Id ?? 0;
            try
            {
                using (var conn = new SqlConnection(_connectionString))
                {
                    conn.Open();
                    using (var cmd = new SqlCommand("UPDATE Orders SET StatusId = @sid WHERE Id = @id", conn))
                    {
                        cmd.Parameters.AddWithValue("@sid", statusId);
                        cmd.Parameters.AddWithValue("@id", orderId);
                        cmd.ExecuteNonQuery();
                    }
                }
                LoadOrders();
                MessageBox.Show("Статус заказа обновлён.", "Заказы", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка:\n" + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private class OrderStatusItem
        {
            public int Id { get; }
            public string Text { get; }
            public OrderStatusItem(int id, string text) { Id = id; Text = text; }
            public override string ToString() => Text;
        }
    }
}

