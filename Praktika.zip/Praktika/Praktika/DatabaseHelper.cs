﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Text.RegularExpressions;

namespace Praktika
{
    internal static class DatabaseHelper
    {
        private const string ConnectionName = "DeliveryWater";
        private const string DatabaseName = "DeliveryWater";
        private static string _resolvedConnectionString;

        public static string GetConnectionString()
        {
            if (!string.IsNullOrWhiteSpace(_resolvedConnectionString))
                return _resolvedConnectionString;

            var fromConfig = ConfigurationManager.ConnectionStrings[ConnectionName]?.ConnectionString ?? string.Empty;
            if (string.IsNullOrWhiteSpace(fromConfig))
                return string.Empty;

            if (CanOpen(fromConfig))
                return _resolvedConnectionString = fromConfig;

            var baseBuilder = new SqlConnectionStringBuilder(fromConfig)
            {
                ConnectTimeout = Math.Min(Math.Max(new SqlConnectionStringBuilder(fromConfig).ConnectTimeout, 2), 5)
            };

            foreach (var ds in GetFallbackDataSources(baseBuilder.DataSource))
            {
                try
                {
                    var b = new SqlConnectionStringBuilder(baseBuilder.ConnectionString) { DataSource = ds };
                    var candidate = b.ConnectionString;
                    if (CanOpen(candidate))
                        return _resolvedConnectionString = candidate;
                }
                catch
                {
                }
            }

            return fromConfig;
        }

        /// <summary>
        /// Обеспечивает наличие БД и минимальной схемы.
        /// </summary>
        public static void EnsureDatabase()
        {
            var cs = GetConnectionString();
            if (string.IsNullOrWhiteSpace(cs))
                return;

            try
            {
                EnsureDatabaseExists(cs);
                EnsureSchema(cs);
            }
            catch
            {
            }
        }

        public static SqlConnection CreateConnection()
        {
            return new SqlConnection(GetConnectionString());
        }

        private static void EnsureDatabaseExists(string connectionString)
        {
            var b = new SqlConnectionStringBuilder(connectionString);
            if (string.Equals(b.InitialCatalog, DatabaseName, StringComparison.OrdinalIgnoreCase) == false)
                b.InitialCatalog = "master";
            else
                b.InitialCatalog = "master";

            using (var conn = new SqlConnection(b.ConnectionString))
            {
                conn.Open();
                using (var cmd = new SqlCommand(
                           $"IF DB_ID(N'{DatabaseName}') IS NULL CREATE DATABASE [{DatabaseName}];",
                           conn))
                {
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private static bool CanOpen(string connectionString)
        {
            try
            {
                var b = new SqlConnectionStringBuilder(connectionString);
                b.ConnectTimeout = Math.Min(Math.Max(b.ConnectTimeout, 2), 5);
                using (var conn = new SqlConnection(b.ConnectionString))
                {
                    conn.Open();
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }

        private static string[] GetFallbackDataSources(string configured)
        {
            var machine = Environment.MachineName;
            return new[]
            {
                @"(localdb)\MSSQLLocalDB",

                @".\SQLEXPRESS",
                $@"{machine}\SQLEXPRESS",
                @"localhost\SQLEXPRESS",

                @".",
                machine,
                @"localhost",

                configured
            };
        }

        private static void EnsureSchema(string connectionString)
        {
            var schemaPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Database", "Schema.sql");
            if (!File.Exists(schemaPath))
                schemaPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Schema.sql");
            if (!File.Exists(schemaPath))
                return;

            var script = File.ReadAllText(schemaPath);

            using (var conn = new SqlConnection(connectionString))
            {
                conn.Open();

                foreach (var batch in SplitSqlBatches(script))
                {
                    using (var cmd = new SqlCommand(batch, conn))
                    {
                        cmd.CommandTimeout = 30;
                        cmd.ExecuteNonQuery();
                    }
                }
            }
        }

        private static string[] SplitSqlBatches(string script)
        {
            var parts = Regex.Split(
                script,
                @"^\s*GO\s*$(\r?\n)?",
                RegexOptions.Multiline | RegexOptions.IgnoreCase);

            var list = new System.Collections.Generic.List<string>(parts.Length);
            foreach (var p in parts)
            {
                var x = p?.Trim();
                if (!string.IsNullOrWhiteSpace(x))
                    list.Add(x);
            }
            return list.ToArray();
        }
    }
}
