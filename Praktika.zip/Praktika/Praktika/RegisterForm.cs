﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Praktika
{
    public partial class RegisterForm : Form
    {
        private readonly string _connectionString;

        public RegisterForm()
        {
            InitializeComponent();
            _connectionString = DatabaseHelper.GetConnectionString();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            var username = txtUsername.Text.Trim();
            var password = txtPassword.Text;
            var confirm = txtConfirmPassword.Text;

            var error = LoginForm.ValidateCredentials(username, password, checkPassword: true);
            if (error != null)
            {
                MessageBox.Show(error, "Некорректный ввод", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (password != confirm)
            {
                MessageBox.Show("Подтверждение пароля не совпадает.", "Ошибка", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(_connectionString))
            {
                MessageBox.Show("Не настроена строка подключения к базе данных.", "Ошибка", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }

            try
            {
                using (var conn = new SqlConnection(_connectionString))
                {
                    conn.Open();
                    using (var checkCmd = new SqlCommand("SELECT COUNT(*) FROM Users WHERE Username = @u", conn))
                    {
                        checkCmd.Parameters.AddWithValue("@u", username);
                        var exists = (int)checkCmd.ExecuteScalar() > 0;
                        if (exists)
                        {
                            MessageBox.Show("Пользователь с таким логином уже существует.", "Ошибка регистрации",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }

                    using (var insertCmd = new SqlCommand(
                               "INSERT INTO Users (Username, Password) VALUES (@u, @p)",
                               conn))
                    {
                        insertCmd.Parameters.AddWithValue("@u", username);
                        insertCmd.Parameters.AddWithValue("@p", password);
                        insertCmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Регистрация прошла успешно. Теперь вы можете войти.", "Успех",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при обращении к базе данных:\n" + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

