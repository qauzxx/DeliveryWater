namespace Praktika
{
    partial class AdminForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.GroupBox groupBoxUsers;
        private System.Windows.Forms.DataGridView dgvUsers;
        private System.Windows.Forms.Panel panelButtons;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnBlockToggle;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel statusLabel;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabUsers;
        private System.Windows.Forms.TabPage tabProducts;
        private System.Windows.Forms.TabPage tabOrders;
        private System.Windows.Forms.TabPage tabReports;
        private System.Windows.Forms.GroupBox groupReports;
        private System.Windows.Forms.DataGridView dgvReports;
        private System.Windows.Forms.Panel panelReports;
        private System.Windows.Forms.Button btnRptOrderCost;
        private System.Windows.Forms.Button btnRptInactiveCustomers;
        private System.Windows.Forms.Button btnRptPopularWaterType;
        private System.Windows.Forms.Button btnRptTopAddresses;
        private System.Windows.Forms.GroupBox groupProducts;
        private System.Windows.Forms.DataGridView dgvProducts;
        private System.Windows.Forms.Panel panelProducts;
        private System.Windows.Forms.Button btnProductsRefresh;
        private System.Windows.Forms.Button btnProductAdd;
        private System.Windows.Forms.Button btnProductEdit;
        private System.Windows.Forms.Button btnProductDelete;
        private System.Windows.Forms.GroupBox groupOrders;
        private System.Windows.Forms.DataGridView dgvOrders;
        private System.Windows.Forms.Panel panelOrders;
        private System.Windows.Forms.Button btnOrdersRefresh;
        private System.Windows.Forms.Label lblOrderStatus;
        private System.Windows.Forms.ComboBox cmbOrderStatus;
        private System.Windows.Forms.Button btnOrderSaveStatus;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.groupBoxUsers = new System.Windows.Forms.GroupBox();
            this.dgvUsers = new System.Windows.Forms.DataGridView();
            this.panelButtons = new System.Windows.Forms.Panel();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnBlockToggle = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.statusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabUsers = new System.Windows.Forms.TabPage();
            this.tabProducts = new System.Windows.Forms.TabPage();
            this.groupProducts = new System.Windows.Forms.GroupBox();
            this.dgvProducts = new System.Windows.Forms.DataGridView();
            this.panelProducts = new System.Windows.Forms.Panel();
            this.btnProductsRefresh = new System.Windows.Forms.Button();
            this.btnProductAdd = new System.Windows.Forms.Button();
            this.btnProductEdit = new System.Windows.Forms.Button();
            this.btnProductDelete = new System.Windows.Forms.Button();
            this.tabOrders = new System.Windows.Forms.TabPage();
            this.groupOrders = new System.Windows.Forms.GroupBox();
            this.dgvOrders = new System.Windows.Forms.DataGridView();
            this.panelOrders = new System.Windows.Forms.Panel();
            this.btnOrdersRefresh = new System.Windows.Forms.Button();
            this.lblOrderStatus = new System.Windows.Forms.Label();
            this.cmbOrderStatus = new System.Windows.Forms.ComboBox();
            this.btnOrderSaveStatus = new System.Windows.Forms.Button();
            this.tabReports = new System.Windows.Forms.TabPage();
            this.groupReports = new System.Windows.Forms.GroupBox();
            this.dgvReports = new System.Windows.Forms.DataGridView();
            this.panelReports = new System.Windows.Forms.Panel();
            this.btnRptOrderCost = new System.Windows.Forms.Button();
            this.btnRptInactiveCustomers = new System.Windows.Forms.Button();
            this.btnRptPopularWaterType = new System.Windows.Forms.Button();
            this.btnRptTopAddresses = new System.Windows.Forms.Button();
            this.groupBoxUsers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUsers)).BeginInit();
            this.panelButtons.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.tabControl.SuspendLayout();
            this.tabUsers.SuspendLayout();
            this.tabProducts.SuspendLayout();
            this.groupProducts.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProducts)).BeginInit();
            this.panelProducts.SuspendLayout();
            this.tabOrders.SuspendLayout();
            this.groupOrders.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrders)).BeginInit();
            this.panelOrders.SuspendLayout();
            this.tabReports.SuspendLayout();
            this.groupReports.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReports)).BeginInit();
            this.panelReports.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxUsers
            // 
            this.groupBoxUsers.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBoxUsers.Controls.Add(this.dgvUsers);
            this.groupBoxUsers.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.groupBoxUsers.Location = new System.Drawing.Point(9, 9);
            this.groupBoxUsers.Name = "groupBoxUsers";
            this.groupBoxUsers.Size = new System.Drawing.Size(1201, 593);
            this.groupBoxUsers.TabIndex = 0;
            this.groupBoxUsers.TabStop = false;
            this.groupBoxUsers.Text = "Пользователи";
            // 
            // dgvUsers
            // 
            this.dgvUsers.AllowUserToAddRows = false;
            this.dgvUsers.AllowUserToDeleteRows = false;
            this.dgvUsers.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvUsers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUsers.Location = new System.Drawing.Point(10, 22);
            this.dgvUsers.Name = "dgvUsers";
            this.dgvUsers.Size = new System.Drawing.Size(1181, 561);
            this.dgvUsers.TabIndex = 0;
            // 
            // panelButtons
            // 
            this.panelButtons.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelButtons.Controls.Add(this.btnRefresh);
            this.panelButtons.Controls.Add(this.btnSave);
            this.panelButtons.Controls.Add(this.btnAdd);
            this.panelButtons.Controls.Add(this.btnBlockToggle);
            this.panelButtons.Controls.Add(this.btnDelete);
            this.panelButtons.Controls.Add(this.btnBack);
            this.panelButtons.Location = new System.Drawing.Point(9, 606);
            this.panelButtons.Name = "panelButtons";
            this.panelButtons.Size = new System.Drawing.Size(1201, 36);
            this.panelButtons.TabIndex = 1;
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(0, 6);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(100, 28);
            this.btnRefresh.TabIndex = 0;
            this.btnRefresh.Text = "Обновить";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(106, 6);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 28);
            this.btnSave.TabIndex = 1;
            this.btnSave.Text = "Сохранить";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(212, 6);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(100, 28);
            this.btnAdd.TabIndex = 2;
            this.btnAdd.Text = "Добавить";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnBlockToggle
            // 
            this.btnBlockToggle.Location = new System.Drawing.Point(318, 6);
            this.btnBlockToggle.Name = "btnBlockToggle";
            this.btnBlockToggle.Size = new System.Drawing.Size(120, 28);
            this.btnBlockToggle.TabIndex = 3;
            this.btnBlockToggle.Text = "Блок / Разблок";
            this.btnBlockToggle.UseVisualStyleBackColor = true;
            this.btnBlockToggle.Click += new System.EventHandler(this.btnBlockToggle_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(444, 6);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(100, 28);
            this.btnDelete.TabIndex = 4;
            this.btnDelete.Text = "Удалить";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnBack
            // 
            this.btnBack.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBack.Location = new System.Drawing.Point(991, 6);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(90, 28);
            this.btnBack.TabIndex = 5;
            this.btnBack.Text = "Назад";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.statusLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 440);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(783, 22);
            this.statusStrip.SizingGrip = false;
            this.statusStrip.TabIndex = 2;
            // 
            // statusLabel
            // 
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(130, 17);
            this.statusLabel.Text = "Всего: 0  |  Активных: 0";
            // 
            // tabControl
            // 
            this.tabControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl.Controls.Add(this.tabUsers);
            this.tabControl.Controls.Add(this.tabProducts);
            this.tabControl.Controls.Add(this.tabOrders);
            this.tabControl.Controls.Add(this.tabReports);
            this.tabControl.Location = new System.Drawing.Point(8, 8);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(767, 427);
            this.tabControl.TabIndex = 0;
            // 
            // tabUsers
            // 
            this.tabUsers.Controls.Add(this.groupBoxUsers);
            this.tabUsers.Controls.Add(this.panelButtons);
            this.tabUsers.Location = new System.Drawing.Point(4, 22);
            this.tabUsers.Name = "tabUsers";
            this.tabUsers.Padding = new System.Windows.Forms.Padding(3);
            this.tabUsers.Size = new System.Drawing.Size(759, 401);
            this.tabUsers.TabIndex = 0;
            this.tabUsers.Text = "Пользователи";
            this.tabUsers.UseVisualStyleBackColor = true;
            // 
            // tabProducts
            // 
            this.tabProducts.Controls.Add(this.groupProducts);
            this.tabProducts.Controls.Add(this.panelProducts);
            this.tabProducts.Location = new System.Drawing.Point(4, 22);
            this.tabProducts.Name = "tabProducts";
            this.tabProducts.Padding = new System.Windows.Forms.Padding(3);
            this.tabProducts.Size = new System.Drawing.Size(759, 401);
            this.tabProducts.TabIndex = 1;
            this.tabProducts.Text = "Каталог воды";
            this.tabProducts.UseVisualStyleBackColor = true;
            // 
            // groupProducts
            // 
            this.groupProducts.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupProducts.Controls.Add(this.dgvProducts);
            this.groupProducts.Location = new System.Drawing.Point(6, 6);
            this.groupProducts.Name = "groupProducts";
            this.groupProducts.Size = new System.Drawing.Size(747, 353);
            this.groupProducts.TabIndex = 0;
            this.groupProducts.TabStop = false;
            this.groupProducts.Text = "Позиции воды и аксессуары";
            // 
            // dgvProducts
            // 
            this.dgvProducts.AllowUserToAddRows = false;
            this.dgvProducts.AllowUserToDeleteRows = false;
            this.dgvProducts.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvProducts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProducts.Location = new System.Drawing.Point(10, 22);
            this.dgvProducts.Name = "dgvProducts";
            this.dgvProducts.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvProducts.Size = new System.Drawing.Size(731, 321);
            this.dgvProducts.TabIndex = 0;
            this.dgvProducts.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvProducts_CellDoubleClick);
            // 
            // panelProducts
            // 
            this.panelProducts.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelProducts.Controls.Add(this.btnProductsRefresh);
            this.panelProducts.Controls.Add(this.btnProductAdd);
            this.panelProducts.Controls.Add(this.btnProductEdit);
            this.panelProducts.Controls.Add(this.btnProductDelete);
            this.panelProducts.Location = new System.Drawing.Point(6, 365);
            this.panelProducts.Name = "panelProducts";
            this.panelProducts.Size = new System.Drawing.Size(747, 30);
            this.panelProducts.TabIndex = 1;
            // 
            // btnProductsRefresh
            // 
            this.btnProductsRefresh.Location = new System.Drawing.Point(0, 4);
            this.btnProductsRefresh.Name = "btnProductsRefresh";
            this.btnProductsRefresh.Size = new System.Drawing.Size(90, 28);
            this.btnProductsRefresh.TabIndex = 0;
            this.btnProductsRefresh.Text = "Обновить";
            this.btnProductsRefresh.UseVisualStyleBackColor = true;
            this.btnProductsRefresh.Click += new System.EventHandler(this.btnProductsRefresh_Click);
            // 
            // btnProductAdd
            // 
            this.btnProductAdd.Location = new System.Drawing.Point(96, 4);
            this.btnProductAdd.Name = "btnProductAdd";
            this.btnProductAdd.Size = new System.Drawing.Size(90, 28);
            this.btnProductAdd.TabIndex = 1;
            this.btnProductAdd.Text = "Добавить";
            this.btnProductAdd.UseVisualStyleBackColor = true;
            this.btnProductAdd.Click += new System.EventHandler(this.btnProductAdd_Click);
            // 
            // btnProductEdit
            // 
            this.btnProductEdit.Location = new System.Drawing.Point(192, 4);
            this.btnProductEdit.Name = "btnProductEdit";
            this.btnProductEdit.Size = new System.Drawing.Size(90, 28);
            this.btnProductEdit.TabIndex = 2;
            this.btnProductEdit.Text = "Изменить";
            this.btnProductEdit.UseVisualStyleBackColor = true;
            this.btnProductEdit.Click += new System.EventHandler(this.btnProductEdit_Click);
            // 
            // btnProductDelete
            // 
            this.btnProductDelete.Location = new System.Drawing.Point(288, 4);
            this.btnProductDelete.Name = "btnProductDelete";
            this.btnProductDelete.Size = new System.Drawing.Size(90, 28);
            this.btnProductDelete.TabIndex = 3;
            this.btnProductDelete.Text = "Удалить";
            this.btnProductDelete.UseVisualStyleBackColor = true;
            this.btnProductDelete.Click += new System.EventHandler(this.btnProductDelete_Click);
            // 
            // tabOrders
            // 
            this.tabOrders.Controls.Add(this.groupOrders);
            this.tabOrders.Controls.Add(this.panelOrders);
            this.tabOrders.Location = new System.Drawing.Point(4, 22);
            this.tabOrders.Name = "tabOrders";
            this.tabOrders.Size = new System.Drawing.Size(759, 401);
            this.tabOrders.TabIndex = 2;
            this.tabOrders.Text = "Заказы";
            this.tabOrders.UseVisualStyleBackColor = true;
            // 
            // tabReports
            // 
            this.tabReports.Controls.Add(this.groupReports);
            this.tabReports.Controls.Add(this.panelReports);
            this.tabReports.Location = new System.Drawing.Point(4, 22);
            this.tabReports.Name = "tabReports";
            this.tabReports.Padding = new System.Windows.Forms.Padding(3);
            this.tabReports.Size = new System.Drawing.Size(759, 401);
            this.tabReports.TabIndex = 3;
            this.tabReports.Text = "Отчёты";
            this.tabReports.UseVisualStyleBackColor = true;
            // 
            // groupReports
            // 
            this.groupReports.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupReports.Controls.Add(this.dgvReports);
            this.groupReports.Location = new System.Drawing.Point(6, 45);
            this.groupReports.Name = "groupReports";
            this.groupReports.Size = new System.Drawing.Size(747, 350);
            this.groupReports.TabIndex = 1;
            this.groupReports.TabStop = false;
            this.groupReports.Text = "Результат";
            // 
            // dgvReports
            // 
            this.dgvReports.AllowUserToAddRows = false;
            this.dgvReports.AllowUserToDeleteRows = false;
            this.dgvReports.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvReports.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvReports.Location = new System.Drawing.Point(10, 19);
            this.dgvReports.Name = "dgvReports";
            this.dgvReports.ReadOnly = true;
            this.dgvReports.Size = new System.Drawing.Size(727, 321);
            this.dgvReports.TabIndex = 0;
            // 
            // panelReports
            // 
            this.panelReports.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelReports.Controls.Add(this.btnRptTopAddresses);
            this.panelReports.Controls.Add(this.btnRptPopularWaterType);
            this.panelReports.Controls.Add(this.btnRptInactiveCustomers);
            this.panelReports.Controls.Add(this.btnRptOrderCost);
            this.panelReports.Location = new System.Drawing.Point(6, 6);
            this.panelReports.Name = "panelReports";
            this.panelReports.Size = new System.Drawing.Size(747, 36);
            this.panelReports.TabIndex = 0;
            // 
            // btnRptOrderCost
            // 
            this.btnRptOrderCost.Location = new System.Drawing.Point(0, 5);
            this.btnRptOrderCost.Name = "btnRptOrderCost";
            this.btnRptOrderCost.Size = new System.Drawing.Size(175, 28);
            this.btnRptOrderCost.TabIndex = 0;
            this.btnRptOrderCost.Text = "Заказы: сумма + доставка 200₽";
            this.btnRptOrderCost.UseVisualStyleBackColor = true;
            this.btnRptOrderCost.Click += new System.EventHandler(this.btnRptOrderCost_Click);
            // 
            // btnRptInactiveCustomers
            // 
            this.btnRptInactiveCustomers.Location = new System.Drawing.Point(181, 5);
            this.btnRptInactiveCustomers.Name = "btnRptInactiveCustomers";
            this.btnRptInactiveCustomers.Size = new System.Drawing.Size(170, 28);
            this.btnRptInactiveCustomers.TabIndex = 1;
            this.btnRptInactiveCustomers.Text = "Клиенты без заказов > 30 дней";
            this.btnRptInactiveCustomers.UseVisualStyleBackColor = true;
            this.btnRptInactiveCustomers.Click += new System.EventHandler(this.btnRptInactiveCustomers_Click);
            // 
            // btnRptPopularWaterType
            // 
            this.btnRptPopularWaterType.Location = new System.Drawing.Point(357, 5);
            this.btnRptPopularWaterType.Name = "btnRptPopularWaterType";
            this.btnRptPopularWaterType.Size = new System.Drawing.Size(160, 28);
            this.btnRptPopularWaterType.TabIndex = 2;
            this.btnRptPopularWaterType.Text = "Самый популярный объём (19л/5л)";
            this.btnRptPopularWaterType.UseVisualStyleBackColor = true;
            this.btnRptPopularWaterType.Click += new System.EventHandler(this.btnRptPopularWaterType_Click);
            // 
            // btnRptTopAddresses
            // 
            this.btnRptTopAddresses.Location = new System.Drawing.Point(523, 5);
            this.btnRptTopAddresses.Name = "btnRptTopAddresses";
            this.btnRptTopAddresses.Size = new System.Drawing.Size(170, 28);
            this.btnRptTopAddresses.TabIndex = 3;
            this.btnRptTopAddresses.Text = "Топ-5 адресов доставок";
            this.btnRptTopAddresses.UseVisualStyleBackColor = true;
            this.btnRptTopAddresses.Click += new System.EventHandler(this.btnRptTopAddresses_Click);
            // 
            // groupOrders
            // 
            this.groupOrders.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupOrders.Controls.Add(this.dgvOrders);
            this.groupOrders.Location = new System.Drawing.Point(6, 6);
            this.groupOrders.Name = "groupOrders";
            this.groupOrders.Size = new System.Drawing.Size(747, 353);
            this.groupOrders.TabIndex = 0;
            this.groupOrders.TabStop = false;
            this.groupOrders.Text = "Список заказов";
            // 
            // dgvOrders
            // 
            this.dgvOrders.AllowUserToAddRows = false;
            this.dgvOrders.AllowUserToDeleteRows = false;
            this.dgvOrders.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvOrders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOrders.Location = new System.Drawing.Point(10, 22);
            this.dgvOrders.Name = "dgvOrders";
            this.dgvOrders.ReadOnly = true;
            this.dgvOrders.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvOrders.Size = new System.Drawing.Size(731, 321);
            this.dgvOrders.TabIndex = 0;
            this.dgvOrders.SelectionChanged += new System.EventHandler(this.dgvOrders_SelectionChanged);
            // 
            // panelOrders
            // 
            this.panelOrders.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelOrders.Controls.Add(this.btnOrdersRefresh);
            this.panelOrders.Controls.Add(this.lblOrderStatus);
            this.panelOrders.Controls.Add(this.cmbOrderStatus);
            this.panelOrders.Controls.Add(this.btnOrderSaveStatus);
            this.panelOrders.Location = new System.Drawing.Point(6, 365);
            this.panelOrders.Name = "panelOrders";
            this.panelOrders.Size = new System.Drawing.Size(747, 30);
            this.panelOrders.TabIndex = 1;
            // 
            // btnOrdersRefresh
            // 
            this.btnOrdersRefresh.Location = new System.Drawing.Point(0, 4);
            this.btnOrdersRefresh.Name = "btnOrdersRefresh";
            this.btnOrdersRefresh.Size = new System.Drawing.Size(90, 28);
            this.btnOrdersRefresh.TabIndex = 0;
            this.btnOrdersRefresh.Text = "Обновить";
            this.btnOrdersRefresh.UseVisualStyleBackColor = true;
            this.btnOrdersRefresh.Click += new System.EventHandler(this.btnOrdersRefresh_Click);
            // 
            // lblOrderStatus
            // 
            this.lblOrderStatus.AutoSize = true;
            this.lblOrderStatus.Location = new System.Drawing.Point(96, 10);
            this.lblOrderStatus.Name = "lblOrderStatus";
            this.lblOrderStatus.Size = new System.Drawing.Size(44, 13);
            this.lblOrderStatus.TabIndex = 1;
            this.lblOrderStatus.Text = "Статус:";
            // 
            // cmbOrderStatus
            // 
            this.cmbOrderStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbOrderStatus.FormattingEnabled = true;
            this.cmbOrderStatus.Location = new System.Drawing.Point(146, 6);
            this.cmbOrderStatus.Name = "cmbOrderStatus";
            this.cmbOrderStatus.Size = new System.Drawing.Size(180, 21);
            this.cmbOrderStatus.TabIndex = 2;
            // 
            // btnOrderSaveStatus
            // 
            this.btnOrderSaveStatus.Location = new System.Drawing.Point(332, 4);
            this.btnOrderSaveStatus.Name = "btnOrderSaveStatus";
            this.btnOrderSaveStatus.Size = new System.Drawing.Size(120, 28);
            this.btnOrderSaveStatus.TabIndex = 3;
            this.btnOrderSaveStatus.Text = "Сохранить статус";
            this.btnOrderSaveStatus.UseVisualStyleBackColor = true;
            this.btnOrderSaveStatus.Click += new System.EventHandler(this.btnOrderSaveStatus_Click);
            // 
            // AdminForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(783, 462);
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.statusStrip);
            this.MinimumSize = new System.Drawing.Size(550, 380);
            this.Name = "AdminForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Администрирование — Сервис доставки воды";
            this.groupBoxUsers.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvUsers)).EndInit();
            this.panelButtons.ResumeLayout(false);
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.tabControl.ResumeLayout(false);
            this.tabUsers.ResumeLayout(false);
            this.tabProducts.ResumeLayout(false);
            this.groupProducts.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvProducts)).EndInit();
            this.panelProducts.ResumeLayout(false);
            this.tabOrders.ResumeLayout(false);
            this.groupOrders.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrders)).EndInit();
            this.panelOrders.ResumeLayout(false);
            this.panelOrders.PerformLayout();
            this.tabReports.ResumeLayout(false);
            this.groupReports.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvReports)).EndInit();
            this.panelReports.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}
