using System;
using System.Drawing;
using System.Windows.Forms;

namespace Praktika
{
    internal enum ThemeScene
    {
        User,
        Admin,
        Courier
    }

    internal static class UiTheme
    {
        public static void Apply(Form form, ThemeScene scene)
        {
            if (form == null) return;
            form.BackgroundImage = null;
            form.BackColor = GetSceneBackColor(scene);
            StyleControls(form.Controls);
        }

        private static void StyleControls(Control.ControlCollection controls)
        {
            foreach (Control control in controls)
            {
                if (control is Button btn)
                {
                    btn.FlatStyle = FlatStyle.Flat;
                    btn.FlatAppearance.BorderColor = Color.FromArgb(60, 120, 180);
                    btn.FlatAppearance.BorderSize = 1;
                    btn.BackColor = Color.FromArgb(235, 247, 255);
                }
                else if (control is GroupBox gb)
                {
                    gb.BackColor = Color.FromArgb(170, 255, 255, 255);
                }
                else if (control is Panel panel)
                {
                    panel.BackColor = Color.FromArgb(120, 255, 255, 255);
                }

                if (control.HasChildren)
                    StyleControls(control.Controls);
            }
        }

        private static Color GetSceneBackColor(ThemeScene scene)
        {
            switch (scene)
            {
                case ThemeScene.Admin:
                    return Color.FromArgb(232, 243, 252);
                case ThemeScene.Courier:
                    return Color.FromArgb(228, 248, 252);
                default:
                    return Color.FromArgb(239, 248, 253);
            }
        }
    }
}
