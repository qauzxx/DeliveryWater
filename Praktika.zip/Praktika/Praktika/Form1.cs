﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace Praktika
{
    public partial class Form1 : Form
    {
        private string _connectionString;
        private DataTable _cartTable;
        private string _searchText = string.Empty;
        private const string ProductScopeFilterSql = @"
AND (
    p.Article LIKE 'WTR%' OR
    c.Name LIKE N'%вода%' OR
    c.Name LIKE N'%помп%' OR
    c.Name LIKE N'%кулер%' OR
    c.Name LIKE N'%тара%' OR
    c.Name LIKE N'%сопутств%'
)";
        private sealed class ReceiptItem
        {
            public string Name { get; set; }
            public decimal Price { get; set; }
            public int Quantity { get; set; }
            public decimal Sum => Price * Quantity;
        }

        public Form1()
        {
            InitializeComponent();
            _connectionString = DatabaseHelper.GetConnectionString();
            _cartTable = new DataTable();
            _cartTable.Columns.Add("ProductId", typeof(int));
            _cartTable.Columns.Add("Название", typeof(string));
            _cartTable.Columns.Add("Цена", typeof(decimal));
            _cartTable.Columns.Add("Кол-во", typeof(int));
            _cartTable.Columns.Add("Сумма", typeof(decimal));
            dgvCart.DataSource = _cartTable;
            dgvCart.Columns["ProductId"].Visible = false;
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            LoadCategories();
            UpdateCartTotal();
        }

        private void LoadCategories()
        {
            try
            {
                cmbCategory.Items.Clear();
                cmbCategory.Items.Add(new ComboItem(0, "-- Все категории --"));
                if (string.IsNullOrEmpty(_connectionString)) return;
                using (var conn = new SqlConnection(_connectionString))
                {
                    conn.Open();
                    using (var cmd = new SqlCommand(@"
SELECT DISTINCT c.Id, c.Name
FROM Categories c
INNER JOIN Products p ON p.CategoryId = c.Id
WHERE (p.IsActive = 1 OR p.IsActive IS NULL) AND p.StockQuantity > 0
" + ProductScopeFilterSql + @"
ORDER BY c.Name", conn))
                    using (var r = cmd.ExecuteReader())
                        while (r.Read())
                            cmbCategory.Items.Add(new ComboItem(r.GetInt32(0), r.GetString(1)));
                }
                if (cmbCategory.Items.Count > 0)
                    cmbCategory.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось загрузить категории. Убедитесь, что в базе есть таблицы Categories и данные.\n" + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void LoadProducts(int? categoryId)
        {
            try
            {
                if (string.IsNullOrEmpty(_connectionString)) return;
                var sql = @"SELECT p.Id, p.Name, m.Name AS Manufacturer, p.Price, p.StockQuantity
FROM Products p
INNER JOIN Manufacturers m ON m.Id = p.ManufacturerId
INNER JOIN Categories c ON c.Id = p.CategoryId
WHERE (p.IsActive = 1 OR p.IsActive IS NULL) AND p.StockQuantity > 0
" + ProductScopeFilterSql;
                if (categoryId.HasValue && categoryId.Value > 0)
                {
                    sql += " AND p.CategoryId = @catId";
                }
                if (!string.IsNullOrWhiteSpace(_searchText))
                {
                    sql += @" AND (
    p.Name LIKE @search OR
    m.Name LIKE @search OR
    ISNULL(p.Article, '') LIKE @search
)";
                }
                sql += " ORDER BY p.Name";
                using (var conn = new SqlConnection(_connectionString))
                using (var da = new SqlDataAdapter(sql, conn))
                {
                    if (categoryId.HasValue && categoryId.Value > 0)
                        da.SelectCommand.Parameters.AddWithValue("@catId", categoryId.Value);
                    if (!string.IsNullOrWhiteSpace(_searchText))
                        da.SelectCommand.Parameters.AddWithValue("@search", "%" + _searchText + "%");
                    var dt = new DataTable();
                    da.Fill(dt);
                    dgvProducts.DataSource = dt;
                    if (dgvProducts.Columns["Id"] != null) dgvProducts.Columns["Id"].Visible = false;
                    if (dgvProducts.Columns["Name"] != null) dgvProducts.Columns["Name"].HeaderText = "Название";
                    if (dgvProducts.Columns["Manufacturer"] != null) dgvProducts.Columns["Manufacturer"].HeaderText = "Бренд";
                    if (dgvProducts.Columns["Price"] != null) dgvProducts.Columns["Price"].HeaderText = "Цена (₽)";
                    if (dgvProducts.Columns["StockQuantity"] != null) dgvProducts.Columns["StockQuantity"].HeaderText = "В наличии";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки каталога воды. Проверьте таблицы Products и Manufacturers.\n" + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void cmbCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            var item = cmbCategory.SelectedItem as ComboItem;
            LoadProducts(item?.Id ?? 0);
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            _searchText = (txtSearch.Text ?? string.Empty).Trim();
            var item = cmbCategory.SelectedItem as ComboItem;
            LoadProducts(item?.Id ?? 0);
        }

        private void btnAddToCart_Click(object sender, EventArgs e)
        {
            if (dgvProducts.CurrentRow == null || dgvProducts.DataSource == null)
            {
                MessageBox.Show("Выберите позицию воды в каталоге.", "Подсказка", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            var row = (dgvProducts.CurrentRow.DataBoundItem as DataRowView)?.Row;
            if (row == null) return;
            int productId = Convert.ToInt32(row["Id"]);
            string name = row["Name"].ToString();
            decimal price = Convert.ToDecimal(row["Price"]);
            int stock = Convert.ToInt32(row["StockQuantity"]);
            int qty = 1;
            var existing = _cartTable.AsEnumerable().FirstOrDefault(r => Convert.ToInt32(r["ProductId"]) == productId);
            if (existing != null)
            {
                qty = Convert.ToInt32(existing["Кол-во"]) + 1;
                if (qty > stock)
                {
                    MessageBox.Show("Недостаточно воды на складе.", "Корзина", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                existing["Кол-во"] = qty;
                existing["Сумма"] = price * qty;
            }
            else
            {
                _cartTable.Rows.Add(productId, name, price, qty, price * qty);
            }
            UpdateCartTotal();
        }

        private void btnRemoveFromCart_Click(object sender, EventArgs e)
        {
            if (dgvCart.CurrentRow == null) return;
            var bound = dgvCart.CurrentRow.DataBoundItem as DataRowView;
            if (bound != null)
                bound.Row.Delete();
            UpdateCartTotal();
        }

        private void btnClearCart_Click(object sender, EventArgs e)
        {
            _cartTable.Rows.Clear();
            UpdateCartTotal();
        }

        private void UpdateCartTotal()
        {
            decimal sum = 0;
            foreach (DataRow r in _cartTable.Rows)
                if (r.RowState != DataRowState.Deleted)
                    sum += Convert.ToDecimal(r["Сумма"]);
            lblCartTotal.Text = "Итого: " + sum.ToString("N0") + " ₽";
        }

        private void btnCheckout_Click(object sender, EventArgs e)
        {
            if (_cartTable.Rows.Count == 0)
            {
                MessageBox.Show("Корзина пуста. Добавьте воду в заказ.", "Заказ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            using (var dlg = new CheckoutForm())
            {
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    if (string.IsNullOrEmpty(_connectionString))
                    {
                        MessageBox.Show("Нет подключения к базе.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    using (var conn = new SqlConnection(_connectionString))
                    {
                        conn.Open();
                        int customerId;
                        using (var cmd = new SqlCommand("SELECT Id FROM Customers WHERE Email = @email", conn))
                        {
                            cmd.Parameters.AddWithValue("@email", dlg.Email);
                            var existing = cmd.ExecuteScalar();
                            if (existing != null && existing != DBNull.Value)
                            {
                                customerId = Convert.ToInt32(existing);
                                using (var upd = new SqlCommand("UPDATE Customers SET FullName=@name, Phone=@phone, Address=@addr WHERE Id=@id", conn))
                                {
                                    upd.Parameters.AddWithValue("@name", dlg.FullName);
                                    upd.Parameters.AddWithValue("@phone", dlg.Phone ?? (object)DBNull.Value);
                                    upd.Parameters.AddWithValue("@addr", dlg.Address ?? (object)DBNull.Value);
                                    upd.Parameters.AddWithValue("@id", customerId);
                                    upd.ExecuteNonQuery();
                                }
                            }
                            else
                            {
                                using (var cmdIns = new SqlCommand(
                                    "INSERT INTO Customers (FullName, Email, Phone, Address) VALUES (@name, @email, @phone, @addr); SELECT SCOPE_IDENTITY();", conn))
                                {
                                    cmdIns.Parameters.AddWithValue("@name", dlg.FullName);
                                    cmdIns.Parameters.AddWithValue("@email", dlg.Email);
                                    cmdIns.Parameters.AddWithValue("@phone", dlg.Phone ?? (object)DBNull.Value);
                                    cmdIns.Parameters.AddWithValue("@addr", dlg.Address ?? (object)DBNull.Value);
                                    customerId = Convert.ToInt32(cmdIns.ExecuteScalar());
                                }
                            }
                        }
                        decimal total = 0;
                        int orderId;
                        using (var cmd = new SqlCommand(
                            "INSERT INTO Orders (CustomerId, StatusId, TotalAmount, DeliveryAddress) VALUES (@cid, 1, 0, @addr); SELECT SCOPE_IDENTITY();", conn))
                        {
                            cmd.Parameters.AddWithValue("@cid", customerId);
                            cmd.Parameters.AddWithValue("@addr", dlg.Address ?? (object)DBNull.Value);
                            orderId = Convert.ToInt32(cmd.ExecuteScalar());
                        }
                        foreach (DataRow r in _cartTable.Rows)
                        {
                            if (r.RowState == DataRowState.Deleted) continue;
                            int pid = Convert.ToInt32(r["ProductId"]);
                            decimal price = Convert.ToDecimal(r["Цена"]);
                            int qty = Convert.ToInt32(r["Кол-во"]);
                            total += price * qty;
                            using (var cmd = new SqlCommand(
                                "INSERT INTO OrderItems (OrderId, ProductId, Quantity, UnitPrice) VALUES (@oid, @pid, @qty, @price)", conn))
                            {
                                cmd.Parameters.AddWithValue("@oid", orderId);
                                cmd.Parameters.AddWithValue("@pid", pid);
                                cmd.Parameters.AddWithValue("@qty", qty);
                                cmd.Parameters.AddWithValue("@price", price);
                                cmd.ExecuteNonQuery();
                            }
                            using (var upd = new SqlCommand("UPDATE Products SET StockQuantity = StockQuantity - @qty WHERE Id = @pid", conn))
                            {
                                upd.Parameters.AddWithValue("@qty", qty);
                                upd.Parameters.AddWithValue("@pid", pid);
                                upd.ExecuteNonQuery();
                            }
                        }
                        using (var cmd = new SqlCommand("UPDATE Orders SET TotalAmount = @total WHERE Id = @id", conn))
                        {
                            cmd.Parameters.AddWithValue("@total", total);
                            cmd.Parameters.AddWithValue("@id", orderId);
                            cmd.ExecuteNonQuery();
                        }
                        var receiptItems = _cartTable.AsEnumerable()
                            .Where(r => r.RowState != DataRowState.Deleted)
                            .Select(r => new ReceiptItem
                            {
                                Name = Convert.ToString(r["Название"]),
                                Price = Convert.ToDecimal(r["Цена"]),
                                Quantity = Convert.ToInt32(r["Кол-во"])
                            })
                            .ToList();
                        SaveReceiptToPdf(orderId, dlg.FullName, dlg.Email, dlg.Phone ?? "", dlg.Address ?? "", total, receiptItems);
                        _cartTable.Rows.Clear();
                        UpdateCartTotal();
                        MessageBox.Show("Заказ на доставку воды № " + orderId + " оформлен. Сумма: " + total.ToString("N0") + " ₽. PDF-чек сохранён в папку «Чеки».", "Спасибо!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка оформления заказа. Проверьте наличие таблиц Customers, Orders, OrderItems, OrderStatuses.\n" + ex.Message,
                        "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void SaveReceiptToPdf(int orderId, string fullName, string email, string phone, string address, decimal total, System.Collections.Generic.List<ReceiptItem> items)
        {
            try
            {
                string folder = Path.Combine(Application.StartupPath, "Чеки");
                if (!Directory.Exists(folder))
                    Directory.CreateDirectory(folder);
                string fileName = string.Format("Чек_заказа_{0}_{1:yyyyMMdd_HHmmss}.pdf", orderId, DateTime.Now);
                string path = Path.Combine(folder, fileName);

                string arialPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Fonts), "arial.ttf");
                BaseFont baseFont = BaseFont.CreateFont(arialPath, BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
                var regular = new iTextSharp.text.Font(baseFont, 10f, iTextSharp.text.Font.NORMAL, new BaseColor(40, 60, 80));
                var bold = new iTextSharp.text.Font(baseFont, 10f, iTextSharp.text.Font.BOLD, BaseColor.BLACK);
                var title = new iTextSharp.text.Font(baseFont, 14f, iTextSharp.text.Font.BOLD, new BaseColor(20, 70, 120));

                var document = new Document(PageSize.A4, 28f, 28f, 24f, 24f);
                using (var fs = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    var writer = PdfWriter.GetInstance(document, fs);
                    writer.CloseStream = false;
                    document.Open();

                    var headerTable = new PdfPTable(2) { WidthPercentage = 100f };
                    headerTable.SetWidths(new[] { 70f, 30f });

                    var leftHeader = new PdfPCell();
                    leftHeader.Border = iTextSharp.text.Rectangle.NO_BORDER;
                    leftHeader.AddElement(new Paragraph("Товарный чек № " + orderId, title));
                    leftHeader.AddElement(new Paragraph("Организация: Praktika Water Delivery", regular));
                    leftHeader.AddElement(new Paragraph("Сайт: https://praktika-water.local", regular));
                    headerTable.AddCell(leftHeader);

                    var rightHeader = new PdfPCell(new Phrase(DateTime.Now.ToString("dd.MM.yyyy HH:mm"), bold));
                    rightHeader.HorizontalAlignment = Element.ALIGN_RIGHT;
                    rightHeader.VerticalAlignment = Element.ALIGN_TOP;
                    rightHeader.Border = iTextSharp.text.Rectangle.NO_BORDER;
                    headerTable.AddCell(rightHeader);
                    document.Add(headerTable);

                    var customerTable = new PdfPTable(2) { WidthPercentage = 100f, SpacingBefore = 10f, SpacingAfter = 10f };
                    customerTable.SetWidths(new[] { 18f, 82f });
                    AddInfoRow(customerTable, "Клиент:", fullName, bold, regular);
                    AddInfoRow(customerTable, "E-mail:", email, bold, regular);
                    AddInfoRow(customerTable, "Телефон:", string.IsNullOrWhiteSpace(phone) ? "-" : phone, bold, regular);
                    AddInfoRow(customerTable, "Адрес:", string.IsNullOrWhiteSpace(address) ? "-" : address, bold, regular);
                    document.Add(customerTable);

                    var itemsTable = new PdfPTable(5) { WidthPercentage = 100f };
                    itemsTable.SetWidths(new[] { 8f, 50f, 14f, 10f, 18f });
                    var headerColor = new BaseColor(214, 237, 255);
                    AddHeaderCell(itemsTable, "№", bold, headerColor);
                    AddHeaderCell(itemsTable, "Наименование", bold, headerColor);
                    AddHeaderCell(itemsTable, "Цена", bold, headerColor);
                    AddHeaderCell(itemsTable, "Кол.", bold, headerColor);
                    AddHeaderCell(itemsTable, "Сумма", bold, headerColor);

                    int index = 1;
                    foreach (var item in items)
                    {
                        AddBodyCell(itemsTable, index.ToString(), regular, Element.ALIGN_CENTER);
                        AddBodyCell(itemsTable, item.Name, regular, Element.ALIGN_LEFT);
                        AddBodyCell(itemsTable, item.Price.ToString("N0") + " руб.", regular, Element.ALIGN_RIGHT);
                        AddBodyCell(itemsTable, item.Quantity.ToString(), regular, Element.ALIGN_CENTER);
                        AddBodyCell(itemsTable, item.Sum.ToString("N0") + " руб.", regular, Element.ALIGN_RIGHT);
                        index++;
                    }

                    var totalLabel = new PdfPCell(new Phrase("К ОПЛАТЕ", bold))
                    {
                        Colspan = 4,
                        HorizontalAlignment = Element.ALIGN_LEFT,
                        Padding = 6f,
                        BorderColor = BaseColor.BLACK
                    };
                    itemsTable.AddCell(totalLabel);
                    var totalValue = new PdfPCell(new Phrase(total.ToString("N0") + " руб.", bold))
                    {
                        HorizontalAlignment = Element.ALIGN_RIGHT,
                        Padding = 6f,
                        BorderColor = BaseColor.BLACK
                    };
                    itemsTable.AddCell(totalValue);
                    document.Add(itemsTable);

                    document.Add(new Paragraph(" ", regular));
                    document.Add(new Paragraph("Спасибо за заказ!", regular) { Alignment = Element.ALIGN_CENTER });
                    document.Close();
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("SaveReceiptPdf: " + ex.Message);
                MessageBox.Show("Заказ оформлен, но не удалось сохранить PDF-чек: " + ex.Message, "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private static void AddInfoRow(PdfPTable table, string label, string value, iTextSharp.text.Font labelFont, iTextSharp.text.Font valueFont)
        {
            var left = new PdfPCell(new Phrase(label, labelFont)) { Border = iTextSharp.text.Rectangle.NO_BORDER, PaddingBottom = 4f };
            var right = new PdfPCell(new Phrase(value, valueFont)) { Border = iTextSharp.text.Rectangle.BOTTOM_BORDER, PaddingBottom = 4f };
            table.AddCell(left);
            table.AddCell(right);
        }

        private static void AddHeaderCell(PdfPTable table, string text, iTextSharp.text.Font font, BaseColor bg)
        {
            var cell = new PdfPCell(new Phrase(text, font))
            {
                HorizontalAlignment = Element.ALIGN_CENTER,
                VerticalAlignment = Element.ALIGN_MIDDLE,
                BackgroundColor = bg,
                Padding = 5f
            };
            table.AddCell(cell);
        }

        private static void AddBodyCell(PdfPTable table, string text, iTextSharp.text.Font font, int align)
        {
            var cell = new PdfPCell(new Phrase(text, font))
            {
                HorizontalAlignment = align,
                VerticalAlignment = Element.ALIGN_MIDDLE,
                Padding = 5f
            };
            table.AddCell(cell);
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Close();
        }

        private class ComboItem
        {
            public int Id { get; }
            public string Text { get; }
            public ComboItem(int id, string text) { Id = id; Text = text; }
            public override string ToString() => Text;
        }
    }
}
