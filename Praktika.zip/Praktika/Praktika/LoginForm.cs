﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Praktika
{
    public partial class LoginForm : Form
    {
        private readonly string _connectionString;
        private readonly Random _random = new Random();
        private readonly PictureBox[] _captchaBoxes;
        private Image[] _captchaTiles;
        private int[] _tileOrder;
        private int _selectedTileIndex = -1;

        public bool IsAdmin { get; private set; }
        public bool IsCourier { get; private set; }
        public string CurrentUserName { get; private set; }

        public LoginForm()
        {
            InitializeComponent();
            _connectionString = DatabaseHelper.GetConnectionString();
            if (string.IsNullOrWhiteSpace(_connectionString))
            {
                MessageBox.Show("Строка подключения DeliveryWater не найдена в App.config", "Ошибка конфигурации",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            _captchaBoxes = new[] { picCaptcha1, picCaptcha2, picCaptcha3, picCaptcha4 };
            for (int i = 0; i < _captchaBoxes.Length; i++)
            {
                _captchaBoxes[i].Tag = i;
                _captchaBoxes[i].Click += CaptchaTile_Click;
            }

            InitializePuzzleCaptcha();
        }

        private void linkRegister_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            using (var reg = new RegisterForm())
            {
                reg.StartPosition = FormStartPosition.CenterParent;
                reg.ShowDialog(this);
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            var username = txtUsername.Text.Trim();
            var password = txtPassword.Text;

            string error = ValidateCredentials(username, password, checkPassword: false);
            if (error != null)
            {
                MessageBox.Show(error, "Некорректный ввод", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Проверка капчи-пазла
            if (!IsPuzzleSolved())
            {
                MessageBox.Show("Сначала соберите картинку-капчу (поменяйте фрагменты местами).", "Капча",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(_connectionString))
            {
                MessageBox.Show("Не настроена строка подключения к базе данных.", "Ошибка", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }

            try
            {
                using (var conn = new SqlConnection(_connectionString))
                {
                    conn.Open();
                    using (var cmd = new SqlCommand(
                               "SELECT Password, ISNULL(IsActive, 1) FROM Users WHERE Username = @u", conn))
                    {
                        cmd.Parameters.AddWithValue("@u", username);
                        using (var reader = cmd.ExecuteReader())
                        {
                            if (!reader.Read())
                            {
                                MessageBox.Show("Пользователь не найден.", "Ошибка авторизации",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                                ShufflePuzzleCaptcha();
                                return;
                            }

                            var storedPassword = reader.GetString(0);
                            var isActive = reader.IsDBNull(1) || reader.GetBoolean(1);
                            if (!isActive)
                            {
                                MessageBox.Show("Пользователь заблокирован. Обратитесь к администратору.", "Ошибка авторизации",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                                ShufflePuzzleCaptcha();
                                return;
                            }

                            if (!string.Equals(storedPassword, password, StringComparison.Ordinal))
                            {
                                MessageBox.Show("Неверный пароль.", "Ошибка авторизации",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                                ShufflePuzzleCaptcha();
                                return;
                            }
                        }
                    }
                }

                CurrentUserName = username;
                IsAdmin = string.Equals(username, "admin", StringComparison.OrdinalIgnoreCase)
                          && string.Equals(password, "admin", StringComparison.Ordinal);
                IsCourier = string.Equals(username, "kura", StringComparison.OrdinalIgnoreCase)
                            && string.Equals(password, "kura", StringComparison.Ordinal);

                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при обращении к базе данных:\n" + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void InitializePuzzleCaptcha()
        {
            _captchaTiles = CreateCaptchaTiles();
            _tileOrder = new[] { 0, 1, 2, 3 };
            ShufflePuzzleCaptcha();
        }

        private void btnCaptchaRefresh_Click(object sender, EventArgs e)
        {
            ShufflePuzzleCaptcha();
        }

        private void CaptchaTile_Click(object sender, EventArgs e)
        {
            var box = sender as PictureBox;
            if (box == null) return;

            int clicked = (int)box.Tag;
            if (_selectedTileIndex < 0)
            {
                _selectedTileIndex = clicked;
                _captchaBoxes[clicked].BorderStyle = BorderStyle.Fixed3D;
                return;
            }

            if (_selectedTileIndex == clicked)
            {
                _captchaBoxes[clicked].BorderStyle = BorderStyle.FixedSingle;
                _selectedTileIndex = -1;
                return;
            }

            int temp = _tileOrder[_selectedTileIndex];
            _tileOrder[_selectedTileIndex] = _tileOrder[clicked];
            _tileOrder[clicked] = temp;

            _captchaBoxes[_selectedTileIndex].BorderStyle = BorderStyle.FixedSingle;
            _selectedTileIndex = -1;
            UpdatePuzzleView();
        }

        private void ShufflePuzzleCaptcha()
        {
            _tileOrder = new[] { 0, 1, 2, 3 };
            do
            {
                for (int i = 0; i < _tileOrder.Length; i++)
                {
                    int j = _random.Next(_tileOrder.Length);
                    int temp = _tileOrder[i];
                    _tileOrder[i] = _tileOrder[j];
                    _tileOrder[j] = temp;
                }
            } while (IsPuzzleSolved());

            _selectedTileIndex = -1;
            for (int i = 0; i < _captchaBoxes.Length; i++)
                _captchaBoxes[i].BorderStyle = BorderStyle.FixedSingle;
            UpdatePuzzleView();
        }

        private void UpdatePuzzleView()
        {
            for (int i = 0; i < _captchaBoxes.Length; i++)
                _captchaBoxes[i].Image = _captchaTiles[_tileOrder[i]];
        }

        private bool IsPuzzleSolved()
        {
            for (int i = 0; i < _tileOrder.Length; i++)
                if (_tileOrder[i] != i) return false;
            return true;
        }

        private Image[] CreateCaptchaTiles()
        {
            var path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "captcha.png");
            if (!File.Exists(path))
                throw new FileNotFoundException("Не найден файл captcha.png рядом с приложением.", path);

            try
            {
                using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    var header = new byte[8];
                    if (fs.Read(header, 0, header.Length) != header.Length ||
                        header[0] != 0x89 || header[1] != 0x50 || header[2] != 0x4E || header[3] != 0x47 ||
                        header[4] != 0x0D || header[5] != 0x0A || header[6] != 0x1A || header[7] != 0x0A)
                    {
                        throw new InvalidDataException("Файл captcha.png не является PNG (неверный заголовок).");
                    }

                    fs.Position = 0;
                    using (var img = Image.FromStream(fs, useEmbeddedColorManagement: true, validateImageData: true))
                    using (var full = new Bitmap(img))
                    {
                        var tiles = new Image[4];
                        int halfW = full.Width / 2;
                        int halfH = full.Height / 2;
                        int idx = 0;

                        for (int y = 0; y < 2; y++)
                        {
                            for (int x = 0; x < 2; x++)
                            {
                                var src = new Rectangle(x * halfW, y * halfH, halfW, halfH);
                                tiles[idx++] = full.Clone(src, PixelFormat.Format32bppArgb);
                            }
                        }

                        return tiles;
                    }
                }
            }
            catch (Exception ex) when (ex is OutOfMemoryException || ex is ArgumentException || ex is InvalidDataException)
            {
                MessageBox.Show(
                    "Не удалось загрузить captcha.png. Убедитесь, что это корректный PNG-файл.\n\n" + ex.Message,
                    "Капча",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                throw;
            }
        }

        internal static string ValidateCredentials(string username, string password, bool checkPassword = true)
        {
            if (string.IsNullOrWhiteSpace(username))
                return "Введите логин.";

            if (!Regex.IsMatch(username, @"^[a-zA-Z0-9_]{3,20}$"))
                return "Логин должен содержать 3–20 символов: латинские буквы, цифры и подчёркивание.";

            if (checkPassword)
            {
                if (string.IsNullOrEmpty(password))
                    return "Введите пароль.";

                if (password.Length < 4)
                    return "Пароль должен содержать не менее 4 символов.";
            }

            return null;
        }
    }
}


