﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Praktika
{
    public partial class ProductEditForm : Form
    {
        private readonly string _conn;
        private const string WaterCategoryFilterSql = @"
WHERE
    Name LIKE N'%вода%' OR
    Name LIKE N'%помп%' OR
    Name LIKE N'%кулер%' OR
    Name LIKE N'%тара%' OR
    Name LIKE N'%сопутств%' OR
    Name LIKE N'%набор%'";
        public int? ProductId { get; set; }
        public string ProductName => txtName.Text.Trim();
        public int CategoryId { get { var i = cmbCategory.SelectedItem as ComboItem; return i != null ? i.Id : 0; } }
        public int ManufacturerId { get { var i = cmbManufacturer.SelectedItem as ComboItem; return i != null ? i.Id : 0; } }
        public decimal Price => numPrice.Value;
        public int Stock => (int)numStock.Value;

        public ProductEditForm(string connectionString)
        {
            InitializeComponent();
            _conn = connectionString;
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            LoadCategories();
            LoadManufacturers();
            if (ProductId.HasValue)
                LoadProduct();
        }

        private void LoadCategories()
        {
            cmbCategory.Items.Clear();
            using (var conn = new SqlConnection(_conn))
            {
                conn.Open();
                using (var cmd = new SqlCommand(
                    "SELECT Id, Name FROM Categories " + WaterCategoryFilterSql + " ORDER BY Name", conn))
                using (var r = cmd.ExecuteReader())
                    while (r.Read())
                        cmbCategory.Items.Add(new ComboItem(r.GetInt32(0), r.GetString(1)));
            }
            if (cmbCategory.Items.Count > 0) cmbCategory.SelectedIndex = 0;
        }

        private void LoadManufacturers()
        {
            cmbManufacturer.Items.Clear();
            using (var conn = new SqlConnection(_conn))
            {
                conn.Open();
                using (var cmd = new SqlCommand("SELECT Id, Name FROM Manufacturers ORDER BY Name", conn))
                using (var r = cmd.ExecuteReader())
                    while (r.Read())
                        cmbManufacturer.Items.Add(new ComboItem(r.GetInt32(0), r.GetString(1)));
            }
            if (cmbManufacturer.Items.Count > 0) cmbManufacturer.SelectedIndex = 0;
        }

        private void LoadProduct()
        {
            using (var conn = new SqlConnection(_conn))
            {
                conn.Open();
                using (var cmd = new SqlCommand("SELECT Name, CategoryId, ManufacturerId, Price, StockQuantity FROM Products WHERE Id = @id", conn))
                {
                    cmd.Parameters.AddWithValue("@id", ProductId.Value);
                    using (var r = cmd.ExecuteReader())
                    {
                        if (!r.Read()) return;
                        txtName.Text = r.GetString(0);
                        int cid = r.GetInt32(1), mid = r.GetInt32(2);
                        for (int i = 0; i < cmbCategory.Items.Count; i++)
                            if ((cmbCategory.Items[i] as ComboItem)?.Id == cid) { cmbCategory.SelectedIndex = i; break; }
                        for (int i = 0; i < cmbManufacturer.Items.Count; i++)
                            if ((cmbManufacturer.Items[i] as ComboItem)?.Id == mid) { cmbManufacturer.SelectedIndex = i; break; }
                        numPrice.Value = Math.Min(Math.Max(r.GetDecimal(3), 0), 99999999);
                        numStock.Value = Math.Min(Math.Max(r.GetInt32(4), 0), 999999);
                    }
                }
            }
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Введите название позиции воды.", "Каталог воды", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtName.Focus();
                return;
            }
            if (cmbCategory.SelectedItem == null || cmbManufacturer.SelectedItem == null)
            {
                MessageBox.Show("Выберите категорию и бренд.", "Каталог воды", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            DialogResult = DialogResult.OK;
            Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private class ComboItem
        {
            public int Id { get; }
            public string Text { get; }
            public ComboItem(int id, string text) { Id = id; Text = text; }
            public override string ToString() => Text;
        }
    }
}
