using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Praktika
{
    internal static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Папка приложения для |DataDirectory| (если будете использовать LocalDB с mdf-файлом)
            AppDomain.CurrentDomain.SetData("DataDirectory", System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory));

            // Создать базу и таблицу Users при первом запуске
            DatabaseHelper.EnsureDatabase();

            // Цикл: вход → форма по роли (User/Admin/Courier) → возврат к окну входа
            while (true)
            {
                using (var login = new LoginForm())
                {
                    if (login.ShowDialog() != DialogResult.OK)
                        break;
                    if (login.IsAdmin)
                    {
                        using (var f = new AdminForm())
                            f.ShowDialog();
                    }
                    else if (login.IsCourier)
                    {
                        using (var f = new CourierForm())
                            f.ShowDialog();
                    }
                    else
                    {
                        using (var f = new Form1())
                            f.ShowDialog();
                    }
                }
            }
        }
    }
}
