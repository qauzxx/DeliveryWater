namespace Praktika
{
    partial class LoginForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.LinkLabel linkRegister;
        private System.Windows.Forms.Label lblCaptchaHint;
        private System.Windows.Forms.Button btnCaptchaRefresh;
        private System.Windows.Forms.Panel panelCaptcha;
        private System.Windows.Forms.PictureBox picCaptcha1;
        private System.Windows.Forms.PictureBox picCaptcha2;
        private System.Windows.Forms.PictureBox picCaptcha3;
        private System.Windows.Forms.PictureBox picCaptcha4;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoginForm));
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblUsername = new System.Windows.Forms.Label();
            this.lblPassword = new System.Windows.Forms.Label();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.btnLogin = new System.Windows.Forms.Button();
            this.linkRegister = new System.Windows.Forms.LinkLabel();
            this.lblCaptchaHint = new System.Windows.Forms.Label();
            this.btnCaptchaRefresh = new System.Windows.Forms.Button();
            this.panelCaptcha = new System.Windows.Forms.Panel();
            this.picCaptcha4 = new System.Windows.Forms.PictureBox();
            this.picCaptcha3 = new System.Windows.Forms.PictureBox();
            this.picCaptcha2 = new System.Windows.Forms.PictureBox();
            this.picCaptcha1 = new System.Windows.Forms.PictureBox();
            this.panelCaptcha.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picCaptcha4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCaptcha3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCaptcha2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCaptcha1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.BackColor = System.Drawing.Color.Transparent;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(53, 18);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(446, 37);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Доставка воды - вход в систему";
            // 
            // lblUsername
            // 
            this.lblUsername.AutoSize = true;
            this.lblUsername.BackColor = System.Drawing.Color.Transparent;
            this.lblUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblUsername.Location = new System.Drawing.Point(110, 142);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(74, 25);
            this.lblUsername.TabIndex = 1;
            this.lblUsername.Text = "Логин:";
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.BackColor = System.Drawing.Color.Transparent;
            this.lblPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblPassword.Location = new System.Drawing.Point(98, 197);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(86, 25);
            this.lblPassword.TabIndex = 2;
            this.lblPassword.Text = "Пароль:";
            // 
            // txtUsername
            // 
            this.txtUsername.Location = new System.Drawing.Point(190, 148);
            this.txtUsername.MaxLength = 20;
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(210, 20);
            this.txtUsername.TabIndex = 3;
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(190, 203);
            this.txtPassword.MaxLength = 50;
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '●';
            this.txtPassword.Size = new System.Drawing.Size(210, 20);
            this.txtPassword.TabIndex = 4;
            // 
            // btnLogin
            // 
            this.btnLogin.BackColor = System.Drawing.Color.Transparent;
            this.btnLogin.Location = new System.Drawing.Point(190, 443);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(210, 50);
            this.btnLogin.TabIndex = 5;
            this.btnLogin.Text = "Войти";
            this.btnLogin.UseVisualStyleBackColor = false;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // linkRegister
            // 
            this.linkRegister.AutoSize = true;
            this.linkRegister.BackColor = System.Drawing.Color.Transparent;
            this.linkRegister.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.linkRegister.LinkColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.linkRegister.Location = new System.Drawing.Point(186, 496);
            this.linkRegister.Name = "linkRegister";
            this.linkRegister.Size = new System.Drawing.Size(206, 19);
            this.linkRegister.TabIndex = 6;
            this.linkRegister.TabStop = true;
            this.linkRegister.Text = "Регистрация нового аккаунта";
            this.linkRegister.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkRegister_LinkClicked);
            // 
            // lblCaptchaHint
            // 
            this.lblCaptchaHint.AutoSize = true;
            this.lblCaptchaHint.BackColor = System.Drawing.Color.Transparent;
            this.lblCaptchaHint.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCaptchaHint.Location = new System.Drawing.Point(56, 243);
            this.lblCaptchaHint.Name = "lblCaptchaHint";
            this.lblCaptchaHint.Size = new System.Drawing.Size(447, 18);
            this.lblCaptchaHint.TabIndex = 7;
            this.lblCaptchaHint.Text = "Капча: соберите картинку (кликните 2 фрагмента для обмена)";
            // 
            // btnCaptchaRefresh
            // 
            this.btnCaptchaRefresh.Location = new System.Drawing.Point(190, 404);
            this.btnCaptchaRefresh.Name = "btnCaptchaRefresh";
            this.btnCaptchaRefresh.Size = new System.Drawing.Size(210, 28);
            this.btnCaptchaRefresh.TabIndex = 8;
            this.btnCaptchaRefresh.Text = "Перемешать капчу";
            this.btnCaptchaRefresh.UseVisualStyleBackColor = true;
            this.btnCaptchaRefresh.Click += new System.EventHandler(this.btnCaptchaRefresh_Click);
            // 
            // panelCaptcha
            // 
            this.panelCaptcha.BackColor = System.Drawing.Color.Transparent;
            this.panelCaptcha.Controls.Add(this.picCaptcha4);
            this.panelCaptcha.Controls.Add(this.picCaptcha3);
            this.panelCaptcha.Controls.Add(this.picCaptcha2);
            this.panelCaptcha.Controls.Add(this.picCaptcha1);
            this.panelCaptcha.Location = new System.Drawing.Point(190, 273);
            this.panelCaptcha.Name = "panelCaptcha";
            this.panelCaptcha.Size = new System.Drawing.Size(162, 162);
            this.panelCaptcha.TabIndex = 9;
            // 
            // picCaptcha4
            // 
            this.picCaptcha4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCaptcha4.Location = new System.Drawing.Point(81, 81);
            this.picCaptcha4.Name = "picCaptcha4";
            this.picCaptcha4.Size = new System.Drawing.Size(80, 80);
            this.picCaptcha4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picCaptcha4.TabIndex = 3;
            this.picCaptcha4.TabStop = false;
            // 
            // picCaptcha3
            // 
            this.picCaptcha3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCaptcha3.Location = new System.Drawing.Point(1, 81);
            this.picCaptcha3.Name = "picCaptcha3";
            this.picCaptcha3.Size = new System.Drawing.Size(80, 80);
            this.picCaptcha3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picCaptcha3.TabIndex = 2;
            this.picCaptcha3.TabStop = false;
            // 
            // picCaptcha2
            // 
            this.picCaptcha2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCaptcha2.Location = new System.Drawing.Point(81, 1);
            this.picCaptcha2.Name = "picCaptcha2";
            this.picCaptcha2.Size = new System.Drawing.Size(80, 80);
            this.picCaptcha2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picCaptcha2.TabIndex = 1;
            this.picCaptcha2.TabStop = false;
            // 
            // picCaptcha1
            // 
            this.picCaptcha1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCaptcha1.Location = new System.Drawing.Point(1, 1);
            this.picCaptcha1.Name = "picCaptcha1";
            this.picCaptcha1.Size = new System.Drawing.Size(80, 80);
            this.picCaptcha1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picCaptcha1.TabIndex = 0;
            this.picCaptcha1.TabStop = false;
            // 
            // LoginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(587, 555);
            this.Controls.Add(this.panelCaptcha);
            this.Controls.Add(this.btnCaptchaRefresh);
            this.Controls.Add(this.lblCaptchaHint);
            this.Controls.Add(this.linkRegister);
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.txtUsername);
            this.Controls.Add(this.lblPassword);
            this.Controls.Add(this.lblUsername);
            this.Controls.Add(this.lblTitle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "LoginForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Вход - Сервис доставки воды";
            this.panelCaptcha.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picCaptcha4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCaptcha3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCaptcha2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCaptcha1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}

