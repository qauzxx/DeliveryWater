﻿-- ============================================
-- Р‘Р°Р·Р° РґР°РЅРЅС‹С…: РњР°РіР°Р·РёРЅ РєРѕРјРїР»РµРєС‚СѓСЋС‰РёС… РґР»СЏ РџРљ
-- РЎРЈР‘Р”: SQL Server (LocalDB / SQL Server Express)
-- ============================================

-- РЎРѕР·РґР°РЅРёРµ Р±Р°Р·С‹ (РѕРїС†РёРѕРЅР°Р»СЊРЅРѕ, РµСЃР»Рё СЃРѕР·РґР°С‘С‚Рµ С‡РµСЂРµР· SSMS вЂ” СЃРѕР·РґР°Р№С‚Рµ Р±Р°Р·Сѓ РІСЂСѓС‡РЅСѓСЋ)
-- CREATE DATABASE DeliveryWater;
-- GO
-- USE DeliveryWater;
-- GO

-- --------------------------------------------
-- 1. РџСЂРѕРёР·РІРѕРґРёС‚РµР»Рё
-- --------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Manufacturers')
CREATE TABLE Manufacturers (
    Id          INT IDENTITY(1,1) PRIMARY KEY,
    Name        NVARCHAR(100) NOT NULL,
    Country     NVARCHAR(50)  NULL,
    Website     NVARCHAR(200) NULL,
    CreatedAt   DATETIME2 DEFAULT GETDATE()
);

-- --------------------------------------------
-- 2. РљР°С‚РµРіРѕСЂРёРё С‚РѕРІР°СЂРѕРІ (РїСЂРѕС†РµСЃСЃРѕСЂС‹, РІРёРґРµРѕРєР°СЂС‚С‹ Рё С‚.Рґ.)
-- --------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Categories')
CREATE TABLE Categories (
    Id          INT IDENTITY(1,1) PRIMARY KEY,
    Name        NVARCHAR(100) NOT NULL,
    Description NVARCHAR(500) NULL,
    ParentId    INT NULL REFERENCES Categories(Id),
    CreatedAt   DATETIME2 DEFAULT GETDATE()
);

-- --------------------------------------------
-- 3. РўРѕРІР°СЂС‹ (РєРѕРјРїР»РµРєС‚СѓСЋС‰РёРµ)
-- --------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Products')
CREATE TABLE Products (
    Id              INT IDENTITY(1,1) PRIMARY KEY,
    CategoryId      INT NOT NULL REFERENCES Categories(Id),
    ManufacturerId  INT NOT NULL REFERENCES Manufacturers(Id),
    Name            NVARCHAR(200) NOT NULL,
    Description     NVARCHAR(MAX) NULL,
    Price           DECIMAL(18,2) NOT NULL CHECK (Price >= 0),
    StockQuantity   INT NOT NULL DEFAULT 0 CHECK (StockQuantity >= 0),
    Article         NVARCHAR(50) NULL UNIQUE,  -- Р°СЂС‚РёРєСѓР»
    WarrantyMonths  INT NULL,
    IsActive        BIT NOT NULL DEFAULT 1,
    CreatedAt       DATETIME2 DEFAULT GETDATE(),
    UpdatedAt       DATETIME2 DEFAULT GETDATE()
);

-- --------------------------------------------
-- 4. РҐР°СЂР°РєС‚РµСЂРёСЃС‚РёРєРё С‚РѕРІР°СЂРѕРІ (РіРёР±РєР°СЏ С‚Р°Р±Р»РёС†Р°: РєР»СЋС‡-Р·РЅР°С‡РµРЅРёРµ)
-- --------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'ProductSpecs')
CREATE TABLE ProductSpecs (
    Id          INT IDENTITY(1,1) PRIMARY KEY,
    ProductId   INT NOT NULL REFERENCES Products(Id) ON DELETE CASCADE,
    SpecName    NVARCHAR(100) NOT NULL,   -- РЅР°РїСЂРёРјРµСЂ: "РЎРѕРєРµС‚", "Р§Р°СЃС‚РѕС‚Р°", "РћР±СЉС‘Рј РїР°РјСЏС‚Рё"
    SpecValue   NVARCHAR(200) NOT NULL,
    UNIQUE (ProductId, SpecName)
);

-- --------------------------------------------
-- 5. РљР»РёРµРЅС‚С‹
-- --------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Customers')
CREATE TABLE Customers (
    Id          INT IDENTITY(1,1) PRIMARY KEY,
    FullName    NVARCHAR(150) NOT NULL,
    Email       NVARCHAR(100) NOT NULL UNIQUE,
    Phone       NVARCHAR(20)  NULL,
    Address     NVARCHAR(300) NULL,
    CreatedAt   DATETIME2 DEFAULT GETDATE()
);

-- --------------------------------------------
-- 6. РЎС‚Р°С‚СѓСЃС‹ Р·Р°РєР°Р·Р°
-- --------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'OrderStatuses')
CREATE TABLE OrderStatuses (
    Id          INT IDENTITY(1,1) PRIMARY KEY,
    Name        NVARCHAR(50) NOT NULL UNIQUE  -- РќРѕРІС‹Р№, РћРїР»Р°С‡РµРЅ, Р’ РґРѕСЃС‚Р°РІРєРµ, Р’С‹РїРѕР»РЅРµРЅ, РћС‚РјРµРЅС‘РЅ
);

-- --------------------------------------------
-- 7. Р—Р°РєР°Р·С‹
-- --------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Orders')
CREATE TABLE Orders (
    Id              INT IDENTITY(1,1) PRIMARY KEY,
    CustomerId      INT NOT NULL REFERENCES Customers(Id),
    StatusId        INT NOT NULL REFERENCES OrderStatuses(Id) DEFAULT 1,
    OrderDate       DATETIME2 DEFAULT GETDATE(),
    TotalAmount     DECIMAL(18,2) NOT NULL DEFAULT 0,
    DeliveryAddress NVARCHAR(300) NULL,
    Notes           NVARCHAR(500) NULL
);

-- --------------------------------------------
-- 8. РџРѕР·РёС†РёРё Р·Р°РєР°Р·Р° (С‚РѕРІР°СЂС‹ РІ Р·Р°РєР°Р·Рµ)
-- --------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'OrderItems')
CREATE TABLE OrderItems (
    Id          INT IDENTITY(1,1) PRIMARY KEY,
    OrderId     INT NOT NULL REFERENCES Orders(Id) ON DELETE CASCADE,
    ProductId   INT NOT NULL REFERENCES Products(Id),
    Quantity    INT NOT NULL CHECK (Quantity > 0),
    UnitPrice   DECIMAL(18,2) NOT NULL,  -- С†РµРЅР° РЅР° РјРѕРјРµРЅС‚ Р·Р°РєР°Р·Р°
    CONSTRAINT UQ_OrderProduct UNIQUE (OrderId, ProductId)
);

-- --------------------------------------------
-- 9. РџРѕР»СЊР·РѕРІР°С‚РµР»Рё (РґР»СЏ Р°РІС‚РѕСЂРёР·Р°С†РёРё)
-- --------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Users')
CREATE TABLE Users (
    Id              INT IDENTITY(1,1) PRIMARY KEY,
    Username        NVARCHAR(50) NOT NULL UNIQUE,
    Password        NVARCHAR(200) NOT NULL,
    IsActive        BIT NOT NULL DEFAULT 1,
    Role            NVARCHAR(20) NOT NULL DEFAULT N'User'
);

-- --------------------------------------------
-- РРЅРґРµРєСЃС‹ РґР»СЏ СѓСЃРєРѕСЂРµРЅРёСЏ Р·Р°РїСЂРѕСЃРѕРІ
-- --------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Products_CategoryId')
    CREATE INDEX IX_Products_CategoryId ON Products(CategoryId);
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Products_ManufacturerId')
    CREATE INDEX IX_Products_ManufacturerId ON Products(ManufacturerId);
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Products_Article')
    CREATE INDEX IX_Products_Article ON Products(Article);
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Orders_CustomerId')
    CREATE INDEX IX_Orders_CustomerId ON Orders(CustomerId);
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Orders_OrderDate')
    CREATE INDEX IX_Orders_OrderDate ON Orders(OrderDate);
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_OrderItems_OrderId')
    CREATE INDEX IX_OrderItems_OrderId ON OrderItems(OrderId);

-- --------------------------------------------
-- РќР°С‡Р°Р»СЊРЅС‹Рµ РґР°РЅРЅС‹Рµ: СЃС‚Р°С‚СѓСЃС‹ Р·Р°РєР°Р·РѕРІ
-- --------------------------------------------
IF NOT EXISTS (SELECT 1 FROM OrderStatuses)
INSERT INTO OrderStatuses (Name) VALUES
    (N'РќРѕРІС‹Р№'),
    (N'РџРѕРґС‚РІРµСЂР¶РґС‘РЅ'),
    (N'РџРµСЂРµРґР°РЅ РєСѓСЂСЊРµСЂСѓ'),
    (N'Р’ РґРѕСЃС‚Р°РІРєРµ'),
    (N'Р”РѕСЃС‚Р°РІР»РµРЅ'),
    (N'РћС‚РјРµРЅС‘РЅ');

-- --------------------------------------------
-- РџСЂРёРјРµСЂ РЅР°С‡Р°Р»СЊРЅС‹С… РґР°РЅРЅС‹С… (РєР°С‚РµРіРѕСЂРёРё Рё РїСЂРѕРёР·РІРѕРґРёС‚РµР»Рё)
-- --------------------------------------------
IF NOT EXISTS (SELECT 1 FROM Categories)
INSERT INTO Categories (Name, Description) VALUES
    (N'Р’РѕРґР° 19 Р»РёС‚СЂРѕРІ', N'РџРёС‚СЊРµРІР°СЏ РІРѕРґР° РІ Р±СѓС‚С‹Р»СЏС… 19 Р»'),
    (N'Р’РѕРґР° 5 Р»РёС‚СЂРѕРІ', N'РџРёС‚СЊРµРІР°СЏ РІРѕРґР° РІ Р±СѓС‚С‹Р»РєР°С… 5 Р»'),
    (N'РњРёРЅРµСЂР°Р»СЊРЅР°СЏ РІРѕРґР°', N'РњРёРЅРµСЂР°Р»СЊРЅР°СЏ РІРѕРґР° Р±РµР· РіР°Р·Р° Рё СЃ РіР°Р·РѕРј'),
    (N'Р“Р°Р·РёСЂРѕРІР°РЅРЅР°СЏ РІРѕРґР°', N'РџРёС‚СЊРµРІР°СЏ РіР°Р·РёСЂРѕРІР°РЅРЅР°СЏ РІРѕРґР°'),
    (N'РџРѕРјРїС‹ Рё РєСѓР»РµСЂС‹', N'РџРѕРјРїС‹, РєСѓР»РµСЂС‹ Рё Р°РєСЃРµСЃСЃСѓР°СЂС‹'),
    (N'РћРґРЅРѕСЂР°Р·РѕРІР°СЏ С‚Р°СЂР°', N'РЎС‚Р°РєР°РЅС‹ Рё РґРµСЂР¶Р°С‚РµР»Рё'),
    (N'РЎРѕРїСѓС‚СЃС‚РІСѓСЋС‰РёРµ С‚РѕРІР°СЂС‹', N'Р§Р°Р№, РєРѕС„Рµ, СЃР°С…Р°СЂ'),
    (N'РђРєС†РёРё Рё РЅР°Р±РѕСЂС‹', N'РљРѕРјРїР»РµРєС‚С‹ Рё РїСЂРѕРјРѕ-РЅР°Р±РѕСЂС‹');

IF NOT EXISTS (SELECT 1 FROM Manufacturers)
INSERT INTO Manufacturers (Name, Country) VALUES
    (N'AquaLife', N'Р РѕСЃСЃРёСЏ'),
    (N'РЎРІСЏС‚РѕР№ РСЃС‚РѕС‡РЅРёРє', N'Р РѕСЃСЃРёСЏ'),
    (N'BonAqua', N'Р РѕСЃСЃРёСЏ'),
    (N'РђСЂС…С‹Р·', N'Р РѕСЃСЃРёСЏ'),
    (N'РЁРёС€РєРёРЅ Р›РµСЃ', N'Р РѕСЃСЃРёСЏ'),
    (N'Nestle', N'РЁРІРµР№С†Р°СЂРёСЏ'),
    (N'AquaPro', N'Р РѕСЃСЃРёСЏ'),
    (N'VodaVoz', N'Р РѕСЃСЃРёСЏ'),
    (N'CoolerMaster Water', N'РљРёС‚Р°Р№'),
    (N'PureDrop', N'Р РѕСЃСЃРёСЏ');

-- РђРґРјРёРЅРёСЃС‚СЂР°С‚РѕСЂ РїРѕ СѓРјРѕР»С‡Р°РЅРёСЋ (Р»РѕРіРёРЅ: admin, РїР°СЂРѕР»СЊ: admin)
IF NOT EXISTS (SELECT 1 FROM Users WHERE Username = N'admin')
INSERT INTO Users (Username, Password, Role)
VALUES (N'admin', N'admin', N'Admin');

IF NOT EXISTS (SELECT 1 FROM Users WHERE Username = N'courier')
INSERT INTO Users (Username, Password, Role)
VALUES (N'courier', N'courier', N'Courier');

-- --------------------------------------------
-- РўСЂРёРіРіРµСЂ: РїРµСЂРµСЃС‡С‘С‚ СЃСѓРјРјС‹ Р·Р°РєР°Р·Р° РїСЂРё РёР·РјРµРЅРµРЅРёРё РїРѕР·РёС†РёР№
-- --------------------------------------------
GO
IF OBJECT_ID('trg_OrderItems_RecalcTotal', 'TR') IS NOT NULL
    DROP TRIGGER trg_OrderItems_RecalcTotal;
GO
CREATE TRIGGER trg_OrderItems_RecalcTotal
ON OrderItems
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH ChangedOrders AS (
        SELECT DISTINCT OrderId FROM inserted
        UNION
        SELECT DISTINCT OrderId FROM deleted
    )
    UPDATE o
    SET o.TotalAmount = ISNULL(x.Total, 0)
    FROM Orders o
    INNER JOIN ChangedOrders c ON c.OrderId = o.Id
    OUTER APPLY (
        SELECT SUM(oi.Quantity * oi.UnitPrice) AS Total
        FROM OrderItems oi
        WHERE oi.OrderId = o.Id
    ) x;
END;
GO

