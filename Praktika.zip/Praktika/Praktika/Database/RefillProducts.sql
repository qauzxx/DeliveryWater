﻿-- РџСЂРёРЅСѓРґРёС‚РµР»СЊРЅР°СЏ РїРµСЂРµР·Р°РїРёСЃСЊ РєР°С‚Р°Р»РѕРіР° РїРѕРґ РґРѕСЃС‚Р°РІРєСѓ РїРёС‚СЊРµРІРѕР№ РІРѕРґС‹
-- Р’РќРРњРђРќРР•: СѓРґР°Р»СЏРµС‚ РІСЃРµ СЃС‚СЂРѕРєРё РёР· OrderItems Рё Products.
USE DeliveryWater;
GO

IF NOT EXISTS (SELECT 1 FROM Categories WHERE Name = N'Р’РѕРґР° 19 Р»РёС‚СЂРѕРІ') INSERT INTO Categories (Name, Description) VALUES (N'Р’РѕРґР° 19 Р»РёС‚СЂРѕРІ', N'РџРёС‚СЊРµРІР°СЏ РІРѕРґР° РІ Р±СѓС‚С‹Р»СЏС… 19 Р»');
IF NOT EXISTS (SELECT 1 FROM Categories WHERE Name = N'Р’РѕРґР° 5 Р»РёС‚СЂРѕРІ') INSERT INTO Categories (Name, Description) VALUES (N'Р’РѕРґР° 5 Р»РёС‚СЂРѕРІ', N'РџРёС‚СЊРµРІР°СЏ РІРѕРґР° РІ Р±СѓС‚С‹Р»РєР°С… 5 Р»');
IF NOT EXISTS (SELECT 1 FROM Categories WHERE Name = N'РњРёРЅРµСЂР°Р»СЊРЅР°СЏ РІРѕРґР°') INSERT INTO Categories (Name, Description) VALUES (N'РњРёРЅРµСЂР°Р»СЊРЅР°СЏ РІРѕРґР°', N'РњРёРЅРµСЂР°Р»СЊРЅР°СЏ РІРѕРґР° Р±РµР· РіР°Р·Р° Рё СЃ РіР°Р·РѕРј');
IF NOT EXISTS (SELECT 1 FROM Categories WHERE Name = N'Р“Р°Р·РёСЂРѕРІР°РЅРЅР°СЏ РІРѕРґР°') INSERT INTO Categories (Name, Description) VALUES (N'Р“Р°Р·РёСЂРѕРІР°РЅРЅР°СЏ РІРѕРґР°', N'РџРёС‚СЊРµРІР°СЏ РіР°Р·РёСЂРѕРІР°РЅРЅР°СЏ РІРѕРґР°');
IF NOT EXISTS (SELECT 1 FROM Categories WHERE Name = N'РџРѕРјРїС‹ Рё РєСѓР»РµСЂС‹') INSERT INTO Categories (Name, Description) VALUES (N'РџРѕРјРїС‹ Рё РєСѓР»РµСЂС‹', N'РџРѕРјРїС‹, РєСѓР»РµСЂС‹ Рё Р°РєСЃРµСЃСЃСѓР°СЂС‹');
IF NOT EXISTS (SELECT 1 FROM Categories WHERE Name = N'РћРґРЅРѕСЂР°Р·РѕРІР°СЏ С‚Р°СЂР°') INSERT INTO Categories (Name, Description) VALUES (N'РћРґРЅРѕСЂР°Р·РѕРІР°СЏ С‚Р°СЂР°', N'РЎС‚Р°РєР°РЅС‹ Рё РґРµСЂР¶Р°С‚РµР»Рё');
IF NOT EXISTS (SELECT 1 FROM Categories WHERE Name = N'РЎРѕРїСѓС‚СЃС‚РІСѓСЋС‰РёРµ С‚РѕРІР°СЂС‹') INSERT INTO Categories (Name, Description) VALUES (N'РЎРѕРїСѓС‚СЃС‚РІСѓСЋС‰РёРµ С‚РѕРІР°СЂС‹', N'Р§Р°Р№, РєРѕС„Рµ, СЃР°С…Р°СЂ');
IF NOT EXISTS (SELECT 1 FROM Categories WHERE Name = N'РђРєС†РёРё Рё РЅР°Р±РѕСЂС‹') INSERT INTO Categories (Name, Description) VALUES (N'РђРєС†РёРё Рё РЅР°Р±РѕСЂС‹', N'РљРѕРјРїР»РµРєС‚С‹ Рё РїСЂРѕРјРѕ-РЅР°Р±РѕСЂС‹');

IF NOT EXISTS (SELECT 1 FROM Manufacturers WHERE Name = N'AquaLife') INSERT INTO Manufacturers (Name, Country) VALUES (N'AquaLife', N'Р РѕСЃСЃРёСЏ');
IF NOT EXISTS (SELECT 1 FROM Manufacturers WHERE Name = N'РЎРІСЏС‚РѕР№ РСЃС‚РѕС‡РЅРёРє') INSERT INTO Manufacturers (Name, Country) VALUES (N'РЎРІСЏС‚РѕР№ РСЃС‚РѕС‡РЅРёРє', N'Р РѕСЃСЃРёСЏ');
IF NOT EXISTS (SELECT 1 FROM Manufacturers WHERE Name = N'BonAqua') INSERT INTO Manufacturers (Name, Country) VALUES (N'BonAqua', N'Р РѕСЃСЃРёСЏ');
IF NOT EXISTS (SELECT 1 FROM Manufacturers WHERE Name = N'РђСЂС…С‹Р·') INSERT INTO Manufacturers (Name, Country) VALUES (N'РђСЂС…С‹Р·', N'Р РѕСЃСЃРёСЏ');
IF NOT EXISTS (SELECT 1 FROM Manufacturers WHERE Name = N'РЁРёС€РєРёРЅ Р›РµСЃ') INSERT INTO Manufacturers (Name, Country) VALUES (N'РЁРёС€РєРёРЅ Р›РµСЃ', N'Р РѕСЃСЃРёСЏ');
IF NOT EXISTS (SELECT 1 FROM Manufacturers WHERE Name = N'Nestle') INSERT INTO Manufacturers (Name, Country) VALUES (N'Nestle', N'РЁРІРµР№С†Р°СЂРёСЏ');
IF NOT EXISTS (SELECT 1 FROM Manufacturers WHERE Name = N'AquaPro') INSERT INTO Manufacturers (Name, Country) VALUES (N'AquaPro', N'Р РѕСЃСЃРёСЏ');
IF NOT EXISTS (SELECT 1 FROM Manufacturers WHERE Name = N'VodaVoz') INSERT INTO Manufacturers (Name, Country) VALUES (N'VodaVoz', N'Р РѕСЃСЃРёСЏ');
IF NOT EXISTS (SELECT 1 FROM Manufacturers WHERE Name = N'CoolerMaster Water') INSERT INTO Manufacturers (Name, Country) VALUES (N'CoolerMaster Water', N'РљРёС‚Р°Р№');
IF NOT EXISTS (SELECT 1 FROM Manufacturers WHERE Name = N'PureDrop') INSERT INTO Manufacturers (Name, Country) VALUES (N'PureDrop', N'Р РѕСЃСЃРёСЏ');

IF EXISTS (SELECT * FROM sys.tables WHERE name = 'OrderItems')
    DELETE FROM OrderItems;

DELETE FROM Products;

INSERT INTO Products (CategoryId, ManufacturerId, Name, Price, StockQuantity, IsActive, Article) VALUES
((SELECT Id FROM Categories WHERE Name = N'Р’РѕРґР° 19 Р»РёС‚СЂРѕРІ'), (SELECT Id FROM Manufacturers WHERE Name = N'AquaLife'), N'AquaLife 19 Р»', 320, 120, 1, N'WTR001'),
((SELECT Id FROM Categories WHERE Name = N'Р’РѕРґР° 19 Р»РёС‚СЂРѕРІ'), (SELECT Id FROM Manufacturers WHERE Name = N'РЁРёС€РєРёРЅ Р›РµСЃ'), N'РЁРёС€РєРёРЅ Р›РµСЃ 19 Р»', 340, 90, 1, N'WTR002'),
((SELECT Id FROM Categories WHERE Name = N'Р’РѕРґР° 19 Р»РёС‚СЂРѕРІ'), (SELECT Id FROM Manufacturers WHERE Name = N'РђСЂС…С‹Р·'), N'РђСЂС…С‹Р· 19 Р»', 360, 70, 1, N'WTR003'),
((SELECT Id FROM Categories WHERE Name = N'Р’РѕРґР° 5 Р»РёС‚СЂРѕРІ'), (SELECT Id FROM Manufacturers WHERE Name = N'BonAqua'), N'BonAqua 5 Р»', 95, 180, 1, N'WTR004'),
((SELECT Id FROM Categories WHERE Name = N'Р’РѕРґР° 5 Р»РёС‚СЂРѕРІ'), (SELECT Id FROM Manufacturers WHERE Name = N'РЎРІСЏС‚РѕР№ РСЃС‚РѕС‡РЅРёРє'), N'РЎРІСЏС‚РѕР№ РСЃС‚РѕС‡РЅРёРє 5 Р»', 90, 200, 1, N'WTR005'),
((SELECT Id FROM Categories WHERE Name = N'Р’РѕРґР° 5 Р»РёС‚СЂРѕРІ'), (SELECT Id FROM Manufacturers WHERE Name = N'PureDrop'), N'PureDrop 5 Р»', 85, 160, 1, N'WTR006'),
((SELECT Id FROM Categories WHERE Name = N'РњРёРЅРµСЂР°Р»СЊРЅР°СЏ РІРѕРґР°'), (SELECT Id FROM Manufacturers WHERE Name = N'РђСЂС…С‹Р·'), N'РђСЂС…С‹Р· РјРёРЅРµСЂР°Р»СЊРЅР°СЏ 1.5 Р»', 70, 220, 1, N'WTR007'),
((SELECT Id FROM Categories WHERE Name = N'РњРёРЅРµСЂР°Р»СЊРЅР°СЏ РІРѕРґР°'), (SELECT Id FROM Manufacturers WHERE Name = N'Nestle'), N'Perrier 0.75 Р»', 180, 80, 1, N'WTR008'),
((SELECT Id FROM Categories WHERE Name = N'Р“Р°Р·РёСЂРѕРІР°РЅРЅР°СЏ РІРѕРґР°'), (SELECT Id FROM Manufacturers WHERE Name = N'BonAqua'), N'BonAqua РіР°Р·РёСЂРѕРІР°РЅРЅР°СЏ 1.5 Р»', 75, 210, 1, N'WTR009'),
((SELECT Id FROM Categories WHERE Name = N'Р“Р°Р·РёСЂРѕРІР°РЅРЅР°СЏ РІРѕРґР°'), (SELECT Id FROM Manufacturers WHERE Name = N'РЎРІСЏС‚РѕР№ РСЃС‚РѕС‡РЅРёРє'), N'РЎРІСЏС‚РѕР№ РСЃС‚РѕС‡РЅРёРє РіР°Р·. 1.5 Р»', 68, 230, 1, N'WTR010'),
((SELECT Id FROM Categories WHERE Name = N'РџРѕРјРїС‹ Рё РєСѓР»РµСЂС‹'), (SELECT Id FROM Manufacturers WHERE Name = N'AquaPro'), N'РџРѕРјРїР° РјРµС…Р°РЅРёС‡РµСЃРєР°СЏ AquaPro', 750, 45, 1, N'WTR011'),
((SELECT Id FROM Categories WHERE Name = N'РџРѕРјРїС‹ Рё РєСѓР»РµСЂС‹'), (SELECT Id FROM Manufacturers WHERE Name = N'CoolerMaster Water'), N'РљСѓР»РµСЂ РЅР°РїРѕР»СЊРЅС‹Р№ CW-200', 7800, 12, 1, N'WTR012'),
((SELECT Id FROM Categories WHERE Name = N'РћРґРЅРѕСЂР°Р·РѕРІР°СЏ С‚Р°СЂР°'), (SELECT Id FROM Manufacturers WHERE Name = N'VodaVoz'), N'РЎС‚Р°РєР°РЅС‡РёРєРё 200 РјР» (100 С€С‚)', 220, 140, 1, N'WTR013'),
((SELECT Id FROM Categories WHERE Name = N'РћРґРЅРѕСЂР°Р·РѕРІР°СЏ С‚Р°СЂР°'), (SELECT Id FROM Manufacturers WHERE Name = N'VodaVoz'), N'Р”РµСЂР¶Р°С‚РµР»СЊ РґР»СЏ СЃС‚Р°РєР°РЅРѕРІ РЅР° РєСѓР»РµСЂ', 550, 55, 1, N'WTR014'),
((SELECT Id FROM Categories WHERE Name = N'РЎРѕРїСѓС‚СЃС‚РІСѓСЋС‰РёРµ С‚РѕРІР°СЂС‹'), (SELECT Id FROM Manufacturers WHERE Name = N'Nestle'), N'РљРѕС„Рµ СЂР°СЃС‚РІРѕСЂРёРјС‹Р№ 190 Рі', 420, 60, 1, N'WTR015'),
((SELECT Id FROM Categories WHERE Name = N'РЎРѕРїСѓС‚СЃС‚РІСѓСЋС‰РёРµ С‚РѕРІР°СЂС‹'), (SELECT Id FROM Manufacturers WHERE Name = N'PureDrop'), N'РЎР°С…Р°СЂ РїРѕСЂС†РёРѕРЅРЅС‹Р№ (500 С€С‚)', 680, 40, 1, N'WTR016');

PRINT N'РљР°С‚Р°Р»РѕРі РІРѕРґС‹ РѕР±РЅРѕРІР»С‘РЅ.';

